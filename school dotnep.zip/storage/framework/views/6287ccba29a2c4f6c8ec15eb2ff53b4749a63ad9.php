

<?php $__env->startPush('styles'); ?>



<?php $__env->stopPush(); ?>

<?php $__env->startSection('headers'); ?>

    
    <div class="row">
        <div class="col-sm-12">
            <div class="float-right page-breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#">Admin</a></li>
                    <li class="breadcrumb-item"><a href="#">Students</a></li>
                    <li class="breadcrumb-item active">Edit</li>
                </ol>
            </div>
            <h5 class="page-title"> <?php echo e(getLanguage('student')); ?>  <?php echo e(getLanguage('edit')); ?></h5>
        </div>
    </div>
    <!-- end row -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>

    
    <div class="row">
        <div class="col-12">
            <div class="card m-b-30">
                <div class="card-body">

                    <h4 class="mt-0 header-title"><?php echo e(getLanguage('student')); ?> <?php echo e(getLanguage('edit')); ?></h4>


                    <form class="" action="<?php echo e(route('admin.student.update')); ?>" method="post" enctype="multipart/form-data">

                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="student_id" value="<?php echo e($student->id); ?>">
                        <div class="row">
                            <div class="col-md-9">
                                <div class="form-group">
                                    <label><?php echo e(getLanguage('full-name')); ?></label>
                                    <input type="text" value="<?php echo e($student->name); ?>" name="name" class="form-control" required placeholder="<?php echo e(getLanguage('full-name')); ?>"/>
                                </div>

                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label><?php echo e(getLanguage('grade')); ?></label>
                                            <select class="form-control" name="grade_id">
                                                <option><?php echo e(getLanguage('grade')); ?> <?php echo e(getLanguage('select')); ?></option>
                                                <?php $__currentLoopData = $grades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option <?php if($grade->id == $student->grade_id): ?> selected <?php endif; ?> value="<?php echo e($grade->id); ?>">
                                                        <?php echo e($grade->title); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label><?php echo e(getLanguage('ethnicity')); ?></label>
                                            <select class="form-control" name="ethnicity_id" required>
                                                <option value=""><?php echo e(getLanguage('ethnicity')); ?> <?php echo e(getLanguage('select')); ?></option>
                                                <?php $__currentLoopData = $ethnicitys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ethnicity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option <?php if($ethnicity->id == $student->ethnicity_id): ?> selected <?php endif; ?> value="<?php echo e($ethnicity->id); ?>">
                                                        <?php echo e($ethnicity->title); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label><?php echo e(getLanguage('address')); ?></label>
                                    <input type="text" value="<?php echo e($student->address); ?>" name="address" class="form-control" required placeholder="<?php echo e(getLanguage('student')); ?> <?php echo e(getLanguage('address')); ?>"/>
                                </div>

                                <div class="form-group">
                                    <label><?php echo e(getLanguage('fathers')); ?> <?php echo e(getLanguage('name')); ?></label>
                                    <input type="text" name="father_name" value="<?php echo e($student->father_name); ?>" class="form-control" required placeholder="<?php echo e(getLanguage('mothers')); ?> <?php echo e(getLanguage('name')); ?>"/>
                                </div>
                                <div class="form-group">
                                    <label><?php echo e(getLanguage('mothers')); ?> <?php echo e(getLanguage('name')); ?></label>
                                    <input type="text" name="mother_name" value="<?php echo e($student->mother_name); ?>" class="form-control" required placeholder="<?php echo e(getLanguage('fathers')); ?> <?php echo e(getLanguage('name')); ?>"/>
                                </div>

                                <div class="form-group">
                                    <label><?php echo e(getLanguage('guardian')); ?> <?php echo e(getLanguage('address')); ?></label>
                                    <input type="text" name="guardian_phone" value="<?php echo e($student->guardian_address); ?>" class="form-control" placeholder="<?php echo e(getLanguage('guardian')); ?> <?php echo e(getLanguage('address')); ?>"/>
                                </div>

                                <div class="form-group">
                                    <label><?php echo e(getLanguage('guardian')); ?> <?php echo e(getLanguage('phone')); ?></label>
                                    <input type="text" value="<?php echo e($student->guardian_phone); ?>" name="guardian_phone" class="form-control" placeholder="<?php echo e(getLanguage('phone')); ?>"/>
                                </div>

                                <div class="row">
                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <label><?php echo e(getLanguage('guardian')); ?> <?php echo e(getLanguage('occupation')); ?></label>
                                            
                                            <select class="form-control" name="occupation_id">
                                                <option><?php echo e(getLanguage('occupation')); ?> <?php echo e(getLanguage('select')); ?></option>
                                                <?php $__currentLoopData = $occupations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $occupation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option <?php if($occupation->id == $student->occupation_id): ?> selected <?php endif; ?> value="<?php echo e($occupation->id); ?>">
                                                        <?php echo e($occupation->title); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <div class="col-md-3">

                                <div class="form-group">
                                    <label><?php echo e(getLanguage('gender')); ?></label>
                                    <select class="form-control" name="gender">
                                        <option><?php echo e(getLanguage('gender')); ?> <?php echo e(getLanguage('select')); ?></option>
                                        <option value="Male" <?php if($student->gender == "Male"): ?> selected <?php endif; ?> >Male</option>
                                        <option value="Female" <?php if($student->gender == "Female"): ?> selected <?php endif; ?> >Female</option>
                                        <option value="Other" <?php if($student->gender == "Other"): ?> selected <?php endif; ?> >Other</option>
                                    </select>
                                </div>


                                <div class="form-group">
                                    <label><?php echo e(getLanguage('disablity')); ?></label>
                                    <select class="form-control" name="disability">
                                        <option><?php echo e(getLanguage('disablity')); ?> ?</option>
                                        <option value="No" <?php if($student->disability == "No"): ?> selected <?php endif; ?> >No</option>
                                        <option value="Yes" <?php if($student->gender == "Yes"): ?> selected <?php endif; ?> >Yes</option>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label><?php echo e(getLanguage('religion')); ?></label>
                                    <select class="form-control" name="religion">
                                        <option><?php echo e(getLanguage('religion')); ?> <?php echo e(getLanguage('select')); ?></option>
                                        <option value="Hindu" <?php if($student->religion == "Hindu"): ?> selected <?php endif; ?> >Hindu</option>
                                        <option value="Christian" <?php if($student->religion == "Christian"): ?> selected <?php endif; ?> >Christian</option>
                                        <option value="Buddhism" <?php if($student->religion == "Buddhism"): ?> selected <?php endif; ?> >Buddhism</option>
                                        <option value="Islam" <?php if($student->religion == "Islam"): ?> selected <?php endif; ?> >Islam</option>
                                        <option value="Other" <?php if($student->religion == "Other"): ?> selected <?php endif; ?> >Other</option>
                                    </select>
                                </div>



                                <div class="form-group">
                                    <label><?php echo e(getLanguage('birth-date')); ?></label>
                                    <input type="text" value="<?php echo e($student->DOB); ?>" id="dob" name="DOB" class="form-control nepali-calendar" />
                                </div>

                                <div class="form-group">
                                    <label><?php echo e(getLanguage('student')); ?> <?php echo e(getLanguage('image')); ?></label>
                                    <input type="file" name="image" class="form-control" />

                                    <?php if($student->image): ?>
                                    <img src="<?php echo e(asset('/thumbnail/'.$student->image)); ?>">
                                        <?php endif; ?>
                                </div>


                            </div>
                        </div>


                        <button type="submit" class="btn btn-success waves-effect waves-light float-right">Update</button>
                    </form>

                </div>
            </div>
        </div> <!-- end col -->
    </div> <!-- end row -->



<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

<!-- Required datatable js -->



<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>