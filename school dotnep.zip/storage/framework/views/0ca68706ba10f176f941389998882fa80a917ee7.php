
<?php if(\Illuminate\Support\Facades\Session::has('error')): ?>

    <div class="alert alert-danger">
        <?php echo session('error'); ?>

    </div>

<?php endif; ?>