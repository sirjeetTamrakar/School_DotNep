

<?php $__env->startPush('style'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

    <div class="sub-banner">
        <div class="img-container">
            <img src="<?php echo e(asset(isset($settings['bannerImage']) ? $settings['bannerImage']: "")); ?>" alt="" />
            <div class="overlay">
                <div class="title">
                    <?php echo e(getFrontLanguage('event')); ?>

                </div>
            </div>
        </div>
    </div>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('front.home')); ?>"><?php echo e(getFrontLanguage('home')); ?></a></li>
            <li class="breadcrumb-item active" aria-current="page">
                <?php echo e(getFrontLanguage('event')); ?>

            </li>
        </ol>
    </nav>
    <div class="news-notice-section">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <div class="content-section">
                        <div class="event-section">
                            <?php if($context->events->isNotEmpty()): ?>
                                <?php $__currentLoopData = $context->events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="row">
                                        <div class="col-md-4">
                                            <a href="<?php echo e(route('front.singleEvent',[$event->id,getNepaliDate($event->created_at)])); ?>">
                                                <div class="img-container">
                                                    <img
                                                            src="<?php echo e(asset('thumbnail/'.$event->image)); ?>"
                                                            alt=""
                                                            class="img-fluid"
                                                    />
                                                </div>
                                            </a>
                                        </div>
                                        <div class="col-md-8">
                                            <div class="title">
                                                <a href="<?php echo e(route('front.singleEvent',[$event->id, getNepaliDate($event->created_at)])); ?>">
                                                    <?php echo e($event->title); ?>

                                                </a>
                                            </div>
                                            <div class="short-description">
                                                <?php echo substr($event->content,0,500); ?>

                                            </div>
                                            <div class="date"><?php echo e(getNepaliDate($event->created_at)); ?></div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="sidebar-section">
                        <div class="sidebar-title"><?php echo e(getFrontLanguage('recent')); ?> <?php echo e(getFrontLanguage('notice-1')); ?></div>
                        <?php if($context->recent_notices->isNotEmpty()): ?>
                            <ul>
                                <?php $__currentLoopData = $context->recent_notices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <a href="<?php echo e(route('front.singleNotice',[$notice->id, getNepaliDate($notice->created_at)])); ?>"><?php echo e($notice->title); ?></a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php else: ?>
                            <span>No recent news to show.</span>
                        <?php endif; ?>
                    </div>
                    <hr />
                    <div class="sidebar-section">
                        <div class="sidebar-title"><?php echo e(getFrontLanguage('recent')); ?> <?php echo e(getFrontLanguage('news-1')); ?></div>
                        <?php if($context->recent_news->isNotEmpty()): ?>
                            <ul>
                                <?php $__currentLoopData = $context->recent_news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <a href="<?php echo e(route('front.singleNews',[$news->id, getNepaliDate($news->created_at)])); ?>"><?php echo e($news->title); ?></a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php else: ?>
                            <span>No recent events to show.</span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('front.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>