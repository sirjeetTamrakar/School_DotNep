

<?php $__env->startPush('style'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

    <div class="sub-banner">
        <div class="img-container">
            <img src="<?php echo e(asset(isset($settings['bannerImage']) ? $settings['bannerImage']: "")); ?>" alt="" />
            <div class="overlay">
                <div class="title">
                    Gallery
                </div>
            </div>
        </div>
    </div>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('front.home')); ?>">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">
                <?php echo e(getFrontLanguage('gallery')); ?>

            </li>
        </ol>
    </nav>
    <div class="gallery-section">
        <div class="container">
            <div class="main-title">
                Albums
            </div>
            <div class="row">
                <?php if($albums->isNotEmpty()): ?>
                    <?php $__currentLoopData = $albums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $album): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4">
                            <div class="album-container">
                                <a href="<?php echo e(route('front.singleAlbum',$album->slug)); ?>">
                                    <div class="img-container">
                                        <img src="<?php echo e(asset(isset($album->gallerys) ? $album->gallerys->first()->image : 'front/assets/images/banner1.jpg')); ?>" alt="<?php echo e($album->title); ?>" />
                                    </div>
                                    <div class="overlay">
                                        <div class="view">
                                            <i class="fa fa-eye"></i>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="album-title">
                                <?php echo e($album->title); ?>

                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <div class="col-md-4">
                        <span>No Albums Present</span>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('front.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>