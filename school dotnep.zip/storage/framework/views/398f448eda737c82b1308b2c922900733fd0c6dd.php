<div class="modal fade " id="add_content" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <form method="post" action="<?php echo e(route('admin.grade.add')); ?>">
            <?php echo csrf_field(); ?>
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel"><?php echo e(getLanguage('add-new')); ?> <?php echo e(getLanguage('grade')); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="title">Full Grade<?php echo e(getLanguage('title')); ?></label>
                        <input type="text" name="title" value="" id="title" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="title">Short Grade title</label>
                        <input type="text" name="subtitle" value="" id="subtitle" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="remarks"><?php echo e(getLanguage('remarks')); ?>:</label>
                        <textarea  name="remarks" id="remarks" class="form-control"></textarea>
                    </div>
                    <div class="form-group">
                        <label for="title"><?php echo e(getLanguage('student')); ?> <?php echo e(getLanguage('information-1')); ?></label>
                        <table class="table table-bordered">
                            <tr>
                                <th><?php echo e(getLanguage('ethnicity')); ?></th>
                                <th><?php echo e(getLanguage('male')); ?> <?php echo e(getLanguage('total')); ?></th>
                                <th><?php echo e(getLanguage('female')); ?> <?php echo e(getLanguage('total')); ?></th>
                            </tr>
                            <?php if($ethnicities->isNotEmpty()): ?>
                            <?php $__currentLoopData = $ethnicities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ethnicity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($ethnicity->title); ?></td>
                                    <td><input type="number" name="ethnicity[male][<?php echo e($ethnicity->id); ?>]" class="form-control"></td>
                                    <td><input type="number" name="ethnicity[female][<?php echo e($ethnicity->id); ?>]" class="form-control"></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <tr>
                                    <td><?php echo e(getLanguage('class-warning')); ?>.</td>
                                    <td><a target="_blank" href="<?php echo e(route('admin.ethnicitys')); ?>">Add New Ethnicity?</a></td>
                                </tr>
                            <?php endif; ?>
                        </table>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save changes</button>
                </div>
            </div>
        </form>
    </div>
</div>
