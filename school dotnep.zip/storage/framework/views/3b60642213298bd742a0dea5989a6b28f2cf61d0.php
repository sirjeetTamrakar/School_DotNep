

<?php $__env->startPush('style'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

    <div class="sub-banner">
        <div class="img-container">
            <img src="<?php echo e(asset(isset($settings['bannerImage'])?$settings['bannerImage']:'')); ?>" alt="" />
            <div class="overlay">
                <div class="title">
                    Events
                </div>
            </div>
        </div>
    </div>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('front.home')); ?>">Home</a></li>
            <li class="breadcrumb-item"><a href="<?php echo e(route('front.events')); ?>">Events</a></li>

            <li class="breadcrumb-item active" aria-current="page">
                <?php echo e($event->title); ?>

            </li>
        </ol>
    </nav>
    <div class="news-notice-section">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <div class="content-section">
                        <div class="event-section">
                            <div class="event-wrapper">
                                <!--<div class="img-container">-->
                                <!--    <img-->
                                <!--            src="<?php echo e(asset($event->image)); ?>"-->
                                <!--            alt=""-->
                                <!--            class="img-fluid"-->
                                <!--    />-->
                                <!--</div>-->
                                <div class="title">
                                    <?php echo e($event->title); ?>

                                </div>
                                <div class="long-description">
                                    <p><?php echo $event->content; ?> </p>
                                </div>
                                <div class="date">
                                    <?php echo e($event->event_date); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="sidebar-section">
                        <div class="sidebar-title">Recent Events</div>
                        <?php if($context->recent_events->isNotEmpty()): ?>
                            <ul>
                                <?php $__currentLoopData = $context->recent_events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <a href="<?php echo e(route('front.singleEvent', [$event->id,getNepaliDate($event->created_at)])); ?>"><?php echo e($event->title); ?></a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('front.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>