

<?php $__env->startPush('style'); ?>
    <link
            rel="stylesheet"
            href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.css"
            
            crossorigin="anonymous"
    />
    <link
            rel="stylesheet"
            href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick-theme.min.css"
            
    />
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

    <div class="computer-lab-section">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="slider-for">
                        <?php if(count($images) > 0): ?>
                            <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div>
                                <div class="img-container">
                                    <img
                                            src="<?php echo e(asset($img)); ?>"
                                            alt=""
                                            class="img-fluid"
                                    />
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <div>
                                <div class="img-container">
                                    <img
                                            src="<?php echo e(asset('front/assets/images/banner2.jpg')); ?>"
                                            alt=""
                                            class="img-fluid"
                                    />
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="slider-nav">
                        <?php if(count($images) > 0): ?>
                            <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div>
                                    <div class="img-container">
                                        <img
                                                src="<?php echo e(asset($img)); ?>"
                                                alt=""
                                                class="img-fluid"
                                        />
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="main-title">
                        <?php echo e($asset_category->title); ?>

                    </div>
                    <div class="brief-description">
                        <p>
                           <?php echo e($asset_category->remarks); ?>

                        </p>
                    </div>
                </div>
            </div>
            
                
            
            
                
                    
                    
                    
                    
                    
                    
                    
                
                
                    
                    
                    
                    
                    
                    
                    
                
            
            <div class="sub-title text-center">
                Items Available
            </div>
            <div class="table-responsive">
                <table class="table table-striped table-bordered table-hover">
                    <thead>
                    <tr>
                        <th>Serial Number</th>
                        <th>Item Name</th>
                        <th>Quantity</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php if(isset($assets)): ?>
                        <?php $__currentLoopData = $assets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$asset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e((int)$key + 1); ?></td>
                                <td><?php echo e($asset->title); ?></td>
                                <td><?php echo e($asset->quantity); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script
            src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.js"
            integrity="sha256-NXRS8qVcmZ3dOv3LziwznUHPegFhPZ1F/4inU7uC8h0="
            crossorigin="anonymous"
    ></script>
    <script>
        $(".slider-for").slick({
            slidesToShow: 1,
            slidesToScroll: 1,
            arrows: false,
            fade: true,
            asNavFor: ".slider-nav"
        });
        $(".slider-nav").slick({
            slidesToShow: 3,
            slidesToScroll: 1,
            asNavFor: ".slider-for",
            dots: true,
            centerMode: true,
            focusOnSelect: true
        });
    </script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('front.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>