

<?php $__env->startPush('style'); ?>
    <style>
        .noticeImage-img{
            width: 100%;
            height: auto;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

    <div class="sub-banner">
        <div class="img-container">
            <img src="<?php echo e(asset(isset($settings['bannerImage'])?$settings['bannerImage']:'')); ?>" alt="" />
            <div class="overlay">
                <div class="title">
                    Notice Detail
                </div>
            </div>
        </div>
    </div>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('front.home')); ?>">Home</a></li>
            <li class="breadcrumb-item"><a href="<?php echo e(route('front.notice')); ?>">Notice</a></li>
            <li class="breadcrumb-item active" aria-current="page">
                Notice Title
            </li>
        </ol>
    </nav>
    <div class="news-notice-section">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <div class="content-section">
                        <div class="notice-section">
                            <div class="notice-detail-wrapper">
                                <div class="main-title">
                                    <?php echo e($notice->title); ?>

                                </div>
                                <?php if(isset($notice->image)): ?>
                                    <div class="noticeImage">
                                        <img class="noticeImage-img" src="<?php echo e(asset($notice->image)); ?>" alt="">
                                    </div>
                                <?php endif; ?>
                                <div class="long-description">
                                    <p>
                                        <?php echo $notice->content; ?>

                                    </p>
                                </div>
                                <div class="date">
                                    <?php echo e(isset($notice->created_at) ? $notice->created_at->format('Y-m-d') : ''); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="sidebar-section">
                        <div class="sidebar-title">Recent Notices</div>
                        <?php if($context->recent_notices->isNotEmpty()): ?>
                            <ul>
                                <?php $__currentLoopData = $context->recent_notices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <a href="<?php echo e(route('front.singleNotice',[$notice->id, getNepaliDate($notice->created_at)])); ?>"><?php echo e($notice->title); ?></a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php else: ?>
                            <span>No recent notices to show.</span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('front.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>