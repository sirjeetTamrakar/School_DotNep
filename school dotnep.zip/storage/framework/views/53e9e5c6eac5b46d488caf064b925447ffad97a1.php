<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <title>Admin</title>
    <meta content="Admin Dashboard" name="description" />
    <meta content="ThemeDesign" name="author" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="shortcut icon" href="<?php echo e(asset('admin/assets/images/favicon.ico')); ?>">

    <!--Morris Chart CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('admin/assets/plugins/morris/morris.css')); ?>">

    <link href="<?php echo e(asset('admin/assets/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">

    <link href="<?php echo e(asset('admin/assets/plugins/summernote/summernote-bs4.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('admin/assets/css/icons.css')); ?>" rel="stylesheet" type="text/css">

    <link href="<?php echo e(asset('admin/assets/css/style.css')); ?>" rel="stylesheet" type="text/css">

    <!-- Sweet Alert -->
    <link href="<?php echo e(asset('admin/assets/plugins/sweet-alert2/sweetalert2.min.css')); ?>" rel="stylesheet" type="text/css">

    <?php echo $__env->yieldPushContent('styles'); ?>
    <script src="https://sdk.accountkit.com/en_US/sdk.js"></script>
</head>


<body class="fixed-left">

<!-- Loader -->
<div id="preloader"><div id="status"><div class="spinner"></div></div></div>

<!-- Begin page -->
<div id="wrapper">

    <?php echo $__env->make('admin.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- Start right Content here -->

    <div class="content-page">
        <!-- Start content -->
        <div class="content">

            <!-- Top Bar Start -->
            <?php echo $__env->make('admin.layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!-- Top Bar End -->

            <div class="page-content-wrapper ">
                <div class="container-fluid">

                    <?php echo $__env->make('admin.layouts.success', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php echo $__env->make('admin.layouts.error', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                
                <?php echo $__env->yieldContent('headers'); ?>

                
                <?php echo $__env->yieldContent('contents'); ?>

                </div>

            </div> <!-- Page content Wrapper -->

        </div> <!-- content -->

        <footer class="footer">
            © 2018 <b>Drixo</b> <span class="d-none d-sm-inline-block"> - Crafted with <i class="mdi mdi-heart text-danger"></i> by Themesdesign.</span>
        </footer>

    </div>
    <!-- End Right content here -->

</div>
<!-- END wrapper -->


<!-- jQuery  -->
<script src="<?php echo e(asset('admin/assets/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/assets/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/assets/js/modernizr.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/assets/js/detect.js')); ?>"></script>
<script src="<?php echo e(asset('admin/assets/js/fastclick.js')); ?>"></script>
<script src="<?php echo e(asset('admin/assets/js/jquery.slimscroll.js')); ?>"></script>
<script src="<?php echo e(asset('admin/assets/js/jquery.blockUI.js')); ?>"></script>
<script src="<?php echo e(asset('admin/assets/js/waves.js')); ?>"></script>
<script src="<?php echo e(asset('admin/assets/js/jquery.nicescroll.js')); ?>"></script>
<script src="<?php echo e(asset('admin/assets/js/jquery.scrollTo.min.js')); ?>"></script>

<script src="<?php echo e(asset('admin/assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js')); ?>"></script>
<!-- skycons -->
<script src="<?php echo e(asset('admin/assets/plugins/skycons/skycons.min.js')); ?>"></script>

<!-- skycons -->
<script src="<?php echo e(asset('admin/assets/plugins/peity/jquery.peity.min.js')); ?>"></script>

<!--Morris Chart-->
<script src="<?php echo e(asset('admin/assets/plugins/morris/morris.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/assets/plugins/raphael/raphael-min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/assets/plugins/summernote/summernote-bs4.min.js')); ?>"></script>
<!-- dashboard -->
<script src="<?php echo e(asset('admin/assets/pages/dashboard.js')); ?>"></script>

 <!-- Sweet-Alert  -->
 <script src="<?php echo e(asset('admin/assets/plugins/sweet-alert2/sweetalert2.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/assets/pages/sweet-alert.init.js')); ?>"></script>

<!-- App js -->
<script src="<?php echo e(asset('admin/assets/js/app.js')); ?>"></script>
<script>
    jQuery(document).ready(function(){
        $('.summernote').summernote({
            height: 150,                 // set editor height
            minHeight: null,             // set minimum height of editor
            maxHeight: null,             // set maximum height of editor
            focus: true                 // set focus to editable area after initializing summernote
        });
    });
</script>

<script>
    jQuery(function() {
        jQuery('#selectlanguage').change(function() {
            this.form.submit();
        });
    });
</script>
<?php echo $__env->yieldPushContent('scripts'); ?>

</body>
</html>

