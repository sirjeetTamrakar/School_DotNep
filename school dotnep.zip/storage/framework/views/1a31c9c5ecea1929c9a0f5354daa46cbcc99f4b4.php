<?php $__env->startPush('styles'); ?>



<?php $__env->stopPush(); ?>

<?php $__env->startSection('headers'); ?>

    
    <div class="row">
        <div class="col-sm-12">
            <div class="float-right page-breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Admin</a></li>
                    <li class="breadcrumb-item "><a href="<?php echo e(route('admin.staff.all')); ?>">Staffs</a></li>
                    <li class="breadcrumb-item "><a href="<?php echo e(route('admin.staff.details',$staff->slug)); ?>"><?php echo e($staff->name); ?></a></li>
                    <li class="breadcrumb-item active"><a href="<?php echo e(route('admin.staff.qualifications',$staff->slug)); ?>">Qualifications</a></li>
                </ol>
            </div>
            <h5 class="page-title"><?php echo e(getLanguage('staff').' '.getLanguage('name')); ?> : <?php echo e($staff->name); ?></h5>
        </div>
    </div>
    <!-- end row -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>

    
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">

                    <h5 class="text-center"><?php echo e(getLanguage('qualifications')); ?></h5>

                    <form action="<?php echo e(route('admin.staff.qualifications_update',$staff->slug)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-12">
                                <table class="table table-bordered table-qualifications">
                                    <thead>
                                    <tr>
                                        <th><?php echo e(getLanguage('serial-1')); ?></th>
                                        <th><?php echo e(getLanguage('details')); ?></th>
                                        <th><?php echo e(getLanguage('action')); ?></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $count=1; ?>
                                    <?php $__currentLoopData = $staff->expriences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr data-row="<?php echo e($count); ?>">
                                            <td><?php echo e($count); ?></td>
                                            <td>
                                                <label for=""><?php echo e(getLanguage('organization-s-name')); ?></label>
                                                <input type="text" placeholder="Organization Name"
                                                       name="exp[organization_name][<?php echo e($exp->id); ?>]"
                                                       value="<?php echo e($exp->organization_name); ?>" class="form-control"
                                                       required>
                                                <label for=""><?php echo e(getLanguage('job-title')); ?></label>
                                                <input type="text" placeholder="Job Title"
                                                       name="exp[job_title][<?php echo e($exp->id); ?>]" value="<?php echo e($exp->job_title); ?>"
                                                       class="form-control" required>
                                                <label for=""><?php echo e(getLanguage('job-location')); ?></label>
                                                <input type="text" placeholder="Job Location"
                                                       name="exp[job_location][<?php echo e($exp->id); ?>]"
                                                       value="<?php echo e($exp->job_location); ?>" class="form-control">
                                                <label><?php echo e(getLanguage('job-start-date')); ?>:</label><input type="date" placeholder="Start Date"
                                                                                 name="exp[start_date][<?php echo e($exp->id); ?>]"
                                                                                 value="<?php echo e($exp->start_date); ?>"
                                                                                 class="form-control" required>
                                                <label><?php echo e(getLanguage('job- end-date')); ?>:</label><input type="date" placeholder="End Date"
                                                                               name="exp[end_date][<?php echo e($exp->id); ?>]"
                                                                               value="<?php echo e($exp->end_date); ?>"
                                                                               class="form-control">
                                            </td>
                                            <td>
                                                <button type="button"
                                                        class="btn btn-danger btn-sm btn-delete-qualifications"
                                                        data-feature=""><i class="fa fa-minus-circle"></i></button>
                                            </td>
                                        </tr>
                                        <?php $count++; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                    <tfoot>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th>
                                            <button class="btn btn-primary btn-sm btn-add-qualifications">
                                                <?php echo e(getLanguage('add-new')); ?>

                                            </button>
                                        </th>
                                    </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>
                        <div class="pull-right">
                            <button class="btn btn-primary">Save Changes</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>


<script>
    function generateRandomInteger() {
        return Math.floor(Math.random() * 90000) + 10000;
    }

    jQuery(document).on('click', '.btn-delete-qualifications', function (e) {
        e.preventDefault();
        var $this = $(this);
        $this.closest("tr").remove();
    });

    jQuery(document).on('click', '.btn-add-qualifications', function (e) {
        e.preventDefault();
        // console.log('tgd');
        var lastRow = $('table.table-qualifications > tbody > tr').last().attr('data-row');
        var counter = lastRow ? parseInt(lastRow) + 1 : 1;
        var randomInteger = generateRandomInteger();

        var newRow = jQuery('<tr data-row="' + counter + '">' +
            '<td>' + counter + '</td>' +
            '<td>' +
            '<label for=""><?php echo e(getLanguage('organization-s-name')); ?></label>' +
            '<input type="text" placeholder="Organization Name" name="exp[organization_name][' + randomInteger + ']" class="form-control" required>' +
            '<label for=""><?php echo e(getLanguage('job-title')); ?></label>' +
            '<input type="text" placeholder="Job Title" name="exp[job_title][' + randomInteger + ']" class="form-control" required>' +
            '<label for=""><?php echo e(getLanguage('job-location')); ?></label>' +
            '<input type="text" placeholder="Job Location" name="exp[job_location][' + randomInteger + ']" class="form-control" required>' +
            '<label><?php echo e(getLanguage('job-start-date')); ?>:</label><input type="date" placeholder="Start Date" name="exp[start_date][' + randomInteger + ']" class="form-control" required>' +
            '<label><?php echo e(getLanguage('job-end-date')); ?>:</label><input type="date" placeholder="End Date" name="exp[end_date][' + randomInteger + ']" class="form-control" required>' +
            '</td>' +
            '<td><button type="button" class="btn btn-danger btn-sm btn-delete-qualifications" data-feature=""><i class="fa fa-minus-circle"></i>&nbsp;<?php echo e(getLanguage('delete')); ?></button></td>' +
            '</tr>');
        jQuery('table.table-qualifications').append(newRow);
    });


</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>