<?php $__env->startPush('style'); ?>

<link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.css"
/>
<link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick-theme.min.css"
/>
<style>
    .slick-slide img{
        display:inline-block;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

    <div style=" background-color: #fff">
        <div id="hospitalCarousel" class="carousel slide" data-ride="carousel">
            <ul class="carousel-indicators">
                <li
                        data-target="#hospitalCarousel"
                        data-slide-to="0"
                        class="active"
                ></li>
                <li data-target="#hospitalCarousel" data-slide-to="1"></li>
                <li data-target="#hospitalCarousel" data-slide-to="2"></li>
            </ul>


            <?php if($context->sliders->isNotEmpty()): ?>
            <div class="carousel-inner">
                <?php $__currentLoopData = $context->sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="carousel-item <?php echo e($context->sliders[0]->id == $slider->id ? 'active' : ''); ?>">
                    <a href="<?php echo e(isset($slider->link)?$slider->link:"#"); ?>">
                        <img
                                src="<?php echo e(asset('large/'.$slider->image)); ?>"
                                alt="<?php echo e($slider->title); ?>"
                                class="img-fluid"
                        />
                    </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                    
                            
                            
                            
                    
                
                
                    
                            
                            
                            
                    
                
            </div>
            <?php endif; ?>

            <a
                    class="carousel-control-prev"
                    href="#hospitalCarousel"
                    data-slide="prev"
            >
                <span class="carousel-control-prev-icon"></span>
            </a>
            <a
                    class="carousel-control-next"
                    href="#hospitalCarousel"
                    data-slide="next"
            >
                <span class="carousel-control-next-icon"></span>
            </a>
        </div>
    </div>

    <div class="welcome-container">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-md-6">
                    <div class="marquee-notice">
                        <div class="title"><?php echo e(getFrontLanguage('notice-1')); ?></div>
                        <div class="content">
                            <div
                                    id="notice-carousel"
                                    class="carousel slide"
                                    data-ride="carousel"
                            >
                                <?php if($context->slider_notices->isNotEmpty()): ?>
                                    <div class="carousel-inner">
                                        <?php $__currentLoopData = $context->slider_notices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="carousel-item <?php if($notice->id == $context->slider_notices[0]->id): ?> active <?php endif; ?>">
                                            <a href=""><?php echo e($notice->title); ?></a>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php else: ?>
                                    <div class="carousel-inner">
                                        <div class="carousel-item">
                                            <a href="#">No notice available !!</a>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="welcome-content">
                        <div class="title">
                            <?php echo e(getFrontLanguage('welcome-to')); ?>  "<?php echo e(isset($settings['name']) ? $settings['name'] : "High School"); ?>"
                        </div>

                        <div class="description">
                            <?php echo isset($settings['welcome_message']) ? $settings['welcome_message'] : ''; ?>

                        </div>
                        <div class="button-container">
                            <a href="<?php echo e(route('front.about')); ?>"><?php echo e(getFrontLanguage('read-more-1')); ?></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="officer-container">
                        <h5><?php echo e(getFrontLanguage('officer')); ?></h5>
                        <div class="officer-item">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-4 col-4">
                                        <div class="img-container">
                                            <img
                                                    src="<?php echo e(asset(isset($settings['adhyaksh_image']) ? 'thumbnail/'.$settings['adhyaksh_image']:'')); ?>"
                                                    alt=""
                                                    class="img-fluid"
                                            />
                                        </div>
                                    </div>
                                    <div class="col-md-8 col-8">
                                        <div class="officer-name"><?php echo e(isset($settings['adhyaksh_name']) ? $settings['adhyaksh_name']:''); ?></div>
                                        <div class="officer-designation">
                                            <?php echo e(getFrontLanguage('ward-chairman')); ?>

                                        </div>
                                        <a href="<?php echo e(route('front.principal-note')); ?>" style="float: right">
                                            <?php echo e(getFrontLanguage('view-message')); ?>&nbsp;<i class="fa fa-arrow-right"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="officer-item">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-4 col-4">
                                        <div class="img-container">
                                            <img
                                                    src="<?php echo e(asset(isset($settings['principal_image']) ? 'thumbnail/'.$settings['principal_image']:'')); ?>"
                                                    alt=""
                                                    class="img-fluid"
                                            />
                                        </div>
                                    </div>
                                    <div class="col-md-8 col-8">
                                        <div class="officer-name"><?php echo e(isset($settings['principal_name']) ? $settings['principal_name']:''); ?></div>
                                        <div class="officer-designation">
                                            <?php echo e(getFrontLanguage('principal')); ?>

                                        </div>
                                        <a href="<?php echo e(route('front.principal-note')); ?>" style="float: right">
                                            <?php echo e(getFrontLanguage('view-message')); ?>&nbsp;<i class="fa fa-arrow-right"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="service-container">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-md-6">
                    <div class="eventTemplate">
                        <div class="event-tabs">
                            <ul class="nav nav-tabs">
                                <li class="nav-item">
                                    <a class="nav-link active" data-toggle="tab" href="#news">
                                        <?php echo e(getFrontLanguage('news-1')); ?>

                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a
                                            class="nav-link"
                                            data-toggle="tab"
                                            href="#tendernotice"
                                    >
                                        <?php echo e(getFrontLanguage('tender-1')." ".getFrontLanguage('notice-1')); ?>

                                    </a>
                                </li>

                                <li class="nav-item">
                                    <a class="nav-link" data-toggle="tab" href="#events">
                                        <?php echo e(getFrontLanguage('event')); ?>

                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a
                                            class="nav-link"
                                            data-toggle="tab"
                                            href="#scholarships"
                                    >
                                        <?php echo e(getFrontLanguage('scholarship-1')); ?>

                                    </a>
                                </li>
                            </ul>
                        </div>
                        <div>
                            <div class="tab-content">
                                <div class="tab-pane container active" id="news">
                                    <div class="tab-detail">
                                        <?php if($context->news->isNotEmpty()): ?>
                                            <?php $__currentLoopData = $context->news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="tab-item">
                                                    <div class="title" style="font-weight:600">
                                                        <a href="<?php echo e(route('front.singleNews',[$news->id,getNepaliDate($news->created_at)])); ?>">
                                                            <?php echo e($news->title); ?>

                                                        </a>
                                                    </div>
                                                    <div class="info">
                                                        <div class="date">
                                                            <?php echo e(isset($news->created_at)?$news->created_at->format('Y-m-d'):""); ?>

                                                        </div>
                                                        <div class="morebtn">
                                                            <a href="<?php echo e(route('front.singleNews',[$news->id,getNepaliDate($news->created_at)])); ?>">
                                                                View <i class="fa fa-arrow-right"></i>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <div class="tab-item">
                                                <div class="title">
                                                    <a href="">
                                                        No News Available Currently.
                                                    </a>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <?php if($context->news->isNotEmpty()): ?>
                                        <div class="morebtn">
                                            <a href="<?php echo e(route('front.news')); ?>">
                                                View More <i class="fa fa-arrow-right"></i>
                                            </a>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="tab-pane container fade" id="tendernotice">
                                    <div class="tab-detail">
                                        <?php if($context->tenders->isNotEmpty()): ?>
                                            <?php $__currentLoopData = $context->tenders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tender): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="tab-item">
                                                    <div class="title" style="font-weight:600">
                                                        <a href="<?php echo e(route('front.singleTender',[$tender->id,getNepaliDate($tender->created_at)])); ?>">
                                                            <?php echo e($tender->title); ?>

                                                        </a>
                                                    </div>
                                                    <div class="info">
                                                        
                                                        <div class="morebtn">
                                                            <a href="<?php echo e(route('front.singleTender',[$tender->id,getNepaliDate($tender->created_at)])); ?>">
                                                                View <i class="fa fa-arrow-right"></i>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <div class="tab-item">
                                                <div class="title">
                                                    <a href="">
                                                        No tenders available currently.
                                                    </a>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <?php if($context->tenders->isNotEmpty()): ?>
                                        <div class="morebtn">
                                            <a href="<?php echo e(route('front.tender')); ?>">
                                                View More <i class="fa fa-arrow-right"></i>
                                            </a>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="tab-pane container fade" id="events">
                                    <div class="tab-detail">
                                        <?php if($context->events->isNotEmpty()): ?>
                                            <?php $__currentLoopData = $context->events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="tab-item">
                                                    <div class="title" style="font-weight:600">
                                                        <a href="<?php echo e(route('front.singleEvent',[$event->id,getNepaliDate($event->created_at)])); ?>">
                                                            <?php echo e($event->title); ?>

                                                        </a>
                                                    </div>
                                                    <div class="info">
                                                        
                                                        <div class="morebtn">
                                                            <a href="<?php echo e(route('front.singleEvent',[$event->id,getNepaliDate($event->created_at)])); ?>">
                                                                View <i class="fa fa-arrow-right"></i>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <div class="tab-item">
                                                <div class="title">
                                                    <a href="">
                                                        No events available currently.
                                                    </a>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <?php if($context->events->isNotEmpty()): ?>
                                        <div class="morebtn">
                                            <a href="<?php echo e(route('front.events')); ?>">
                                                View More <i class="fa fa-arrow-right"></i>
                                            </a>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="tab-pane container fade" id="scholarships">
                                    <div class="tab-detail">
                                        <?php if($context->scholarships->isNotEmpty()): ?>
                                            <?php $__currentLoopData = $context->scholarships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $scholarship): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="tab-item">
                                                <div class="title" style="font-weight:600">
                                                    <a href="">
                                                        <?php echo e($scholarship->title); ?>

                                                    </a>
                                                </div>
                                                <div class="info">
                                                    <div class="date"><?php echo e(getNepaliDate($scholarship->created_at)); ?></div>
                                                    <div class="morebtn">
                                                        <a href="<?php echo e(route('front.singleScholarship',[$scholarship->id,getNepaliDate($scholarship->created_at)])); ?>">
                                                            View <i class="fa fa-arrow-right"></i>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <div class="tab-item">
                                            <div class="title">
                                                <a href="">
                                                    No Scholarship Available
                                                </a>
                                            </div>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                    <?php if($context->scholarships->isNotEmpty()): ?>
                                        <div class="morebtn">
                                            <a href="<?php echo e(route('front.scholarship')); ?>">
                                                View More <i class="fa fa-arrow-right"></i>
                                            </a>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="eventTemplate">
                        <div class="main-title">
                            <?php echo e(getFrontLanguage('notice-1')); ?>

                        </div>

                        <div class="tab-pane container active">
                            <div class="tab-detail">
                                <?php if($context->block_notices->isNotEmpty()): ?>
                                    <?php $__currentLoopData = $context->block_notices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="tab-item">
                                            <div class="title" style="font-weight:600">
                                                <?php echo e($notice->title); ?>

                                            </div>
                                            <div class="info">
                                                <div class="date">
                                                    <?php echo e(getNepaliDate($notice->created_at)); ?>

                                                </div>
                                                <div class="morebtn">
                                                    <a href="<?php echo e(route('front.singleNotice',[$notice->id,getNepaliDate($notice->created_at)])); ?>">
                                                        View <i class="fa fa-arrow-right"></i>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <div class="tab-item">
                                        <div class="title">
                                            <a href="">
                                                No Notice Available !!
                                            </a>
                                        </div>
                                    </div>
                                <?php endif; ?>

                            </div>
                            <div class="morebtn">
                                <a href="<?php echo e(route('front.notice')); ?>">
                                    View More <i class="fa fa-arrow-right"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="facilities">
        <div class="main-title">
             <?php echo e(getFrontLanguage('gallery')); ?>

        </div>
        <div class="gallery-section">
        <div class="container">
            <div class="row">
                <?php if($albums->isNotEmpty()): ?>
                    <?php $__currentLoopData = $albums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $album): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4">
                            <div class="album-container">
                                <a href="<?php echo e(route('front.singleAlbum',$album->slug)); ?>">
                                    <div class="img-container">
                                        <img src="<?php echo e(asset(isset($album->gallerys) ? $album->gallerys->first()->image : 'front/assets/images/banner1.jpg')); ?>" alt="<?php echo e($album->title); ?>" />
                                    </div>
                                    <div class="overlay">
                                        <div class="view">
                                            <i class="fa fa-eye"></i>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="album-title">
                                <?php echo e($album->title); ?>

                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <div class="col-md-4">
                        <span>No Albums Present</span>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    </div>
    
    <div class="facilities">
        <div class="main-title">
            <?php echo e(getFrontLanguage('our-staff-members')); ?>

        </div>
        <div class="sub-title">
            Our generous and hardworking staff members.
        </div>
        <div class="container">
            <div class="teacherSlider">
                <?php $__currentLoopData = $context->staffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div>
                        <div class="facility-item">
                            <div class="img-container">
                                <img
                                        src="<?php echo e(asset('thumbnail/'.$staff->image)); ?>"
                                        alt=""
                                        class="img-fluid"
                                />
                            </div>
                            <div class="facility-title">
                                <?php echo e($staff->name); ?>

                            </div>
                            <div class="facility-designation">
                                <?php echo e($staff->job_title); ?>

                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    
    
    


    
        
            
        
        
            
        
        
            
                
                    
                        
                        
                            
                                
                                    
                                            
                                            
                                            
                                    
                                
                                
                                    
                                
                            
                        
                    
                
            
        
    
    <div class="counter-container">
        <div class="container">
            <div class="main-title">
                <?php echo e(getFrontLanguage('our-school-family')); ?>

            </div>
            <div class="sub-title">
                We strive towards success and greatness.
            </div>
            <div class="row text-center">
                <div class="col-md-4">
                    <div class="counter">
                        <h2
                                class="timer count-title count-number"
                                data-to="<?php echo e(isset($settings['total_administrations']) ? $settings['total_administrations'] : ""); ?>"
                                data-speed="3000"
                        ></h2>
                        <p class="count-text "><?php echo e(getFrontLanguage('administration-members')); ?></p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="counter">
                        <h2
                                class="timer count-title count-number"
                                data-to="<?php echo e(isset($settings['total_teachers']) ? $settings['total_teachers'] : ""); ?>"
                                data-speed="3000"
                        ></h2>
                        <p class="count-text "><?php echo e(getFrontLanguage('our-excellent-teachers')); ?></p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="counter">
                        <h2
                                class="timer count-title count-number"
                                data-to="<?php echo e(isset($settings['total_student']) ? $settings['total_student'] : ""); ?>"
                                data-speed="3000"
                        ></h2>
                        <p class="count-text "><?php echo e(getFrontLanguage('our-genius-students')); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
        
                
                
                
        
            
                
                        
                        
                        
                
                
                
            

            
                
                    
                    
                        
                            
                                
                                    
                                    
                                        
                                        
                                        
                                    
                                    
                                        
                                        
                                        
                                    
                                    
                                    
                                        
                                    
                                
                            

                            
                                
                                    
                                            
                                            
                                            
                                    
                                
                            
                        
                    
                    
                
                    
                        
                            
                                
                                    
                                    
                                        
                                    
                                    
                                    
                                        
                                    
                                
                            

                            
                                
                                    
                                            
                                            
                                            
                                    
                                
                            
                        
                    
                
            

            
                    
                    
                    
            
                
            
            
                    
                    
                    
            
                
            
        
    

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>


<script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.js"></script>

<script>
    $(".teacherSlider").slick({
        slidesToShow: 4,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 2000,
        responsive: [
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 3,
                    infinite: true,
                    dots: true,
                },
            },
            {
                breakpoint: 600,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1,
                },
            },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1,
                },
            },
        ],
    });

</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('front.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>