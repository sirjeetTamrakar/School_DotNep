<?php $__env->startPush('styles'); ?>

    <style>
        .quick-links{
            text-align: center;
            font-weight: 800 !important;
        }
    </style>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('headers'); ?>

    
    <div class="row">
        <div class="col-sm-12">
            <div class="float-right page-breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#">Admin</a></li>
                </ol>
            </div>
            <h5 class="page-title"> Dashboard </h5>
        </div>
    </div>
    <!-- end row -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>

    

    <div class="row">
        <div class="col-xl-3 col-md-6">
            <div class="card mini-stat m-b-30">
                <div class="p-3 bg-primary text-white">
                    <div class="mini-stat-icon">
                        <i class="mdi mdi-account-multiple float-right mb-0"></i>
                    </div>
                    <h6 class="text-uppercase mb-0">Total Student</h6>
                </div>
                <div class="card-body">
                    <div class="mt-4 text-muted">
                        <div class="float-right">
                            <p class="m-0"><a href="<?php echo e(route('admin.grade.students')); ?>">View</a></p>
                        </div>
                        <h5 class="m-0"><?php echo e(getAbout('total_student')); ?></h5>
                        
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="card mini-stat m-b-30">
                <div class="p-3 bg-primary text-white">
                    <div class="mini-stat-icon">
                        <i class="mdi mdi-account-box-outline float-right mb-0"></i>
                    </div>
                    <h6 class="text-uppercase mb-0">Total Staff</h6>
                </div>
                <div class="card-body">
                    <div class="mt-4 text-muted">
                        <div class="float-right">
                            <p class="m-0"><a href="<?php echo e(route('admin.staff.all')); ?>">View More</a></p>
                        </div>
                        <h5 class="m-0"><?php echo e($context->staff_count); ?></h5>

                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="card mini-stat m-b-30">
                <div class="p-3 bg-primary text-white">
                    <div class="mini-stat-icon">
                        <i class="mdi mdi-gender-female float-right mb-0"></i>
                    </div>
                    <h6 class="text-uppercase mb-0">Total Male</h6>
                </div>
                <div class="card-body">
                    <div class="mt-4 text-muted">
                        <div class="float-right">
                            
                        </div>
                        <h5 class="m-0"><?php echo e(getAbout('male_student')); ?></h5>

                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="card mini-stat m-b-30">
                <div class="p-3 bg-primary text-white">
                    <div class="mini-stat-icon">
                        <i class="mdi mdi-gender-male float-right mb-0"></i>
                    </div>
                    <h6 class="text-uppercase mb-0">Total Female</h6>
                </div>
                <div class="card-body">
                    <div class="mt-4 text-muted">
                        <div class="float-right">
                            
                        </div>
                        <h5 class="m-0"><?php echo e(getAbout('female_student')); ?></h5>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- end row -->

    <!-- Quick Links row -->
    <div class="row">
        <h5>Quick Links</h5>
    </div>
    <div class="row">
        <div class="col-xl-3">
            <a href="<?php echo e(route('admin.notice.all')); ?>">
            <div class="card m-b-30 text-white bg-success">
                <div class="card-body">
                    <blockquote class="card-bodyquote mb-0">
                        <p class="quick-links">School Notices.</p>
                        
                            
                        
                    </blockquote>
                </div>
            </div>
            </a>
        </div>
        <div class="col-xl-3">
            <a href="<?php echo e(route('admin.news.all')); ?>">
            <div class="card m-b-30 text-white bg-info">
                <div class="card-body">
                    <blockquote class="card-bodyquote mb-0">
                        <p class="quick-links">School News.</p>
                        
                            
                        
                    </blockquote>
                </div>
            </div>
            </a>
        </div>
        <div class="col-xl-3">
            <a href="<?php echo e(route('admin.event.all')); ?>">
            <div class="card m-b-30 text-white bg-danger">
                <div class="card-body">
                    <blockquote class="card-bodyquote mb-0">
                        <p class="quick-links">School Events.</p>
                        
                            
                        
                    </blockquote>
                </div>
            </div>
            </a>
        </div>
        <div class="col-xl-3">
            <a href="<?php echo e(route('admin.tender.all')); ?>">
            <div class="card m-b-30 text-white bg-warning">
                <div class="card-body">
                    <blockquote class="card-bodyquote mb-0">
                        <p class="quick-links">School Tenders.</p>
                        
                            
                        
                    </blockquote>
                </div>
            </div>
            </a>
        </div>
    </div>
    <!-- End Quick Links-->

    <!-- Site Management Links-->
    <div class="row">
        <h5>FrontPage Management Links</h5>
    </div>
    <div class="row">
        <div class="col-xl-3">
            <a href="<?php echo e(route('admin.sliders')); ?>">
                <div class="card m-b-30 text-white bg-success">
                    <div class="card-body">
                        <blockquote class="card-bodyquote mb-0">
                            <p class="quick-links">HomePage Sliders.</p>
                            
                            
                            
                        </blockquote>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-xl-3">
            <a href="<?php echo e(route('admin.album.all')); ?>">
                <div class="card m-b-30 text-white bg-info">
                    <div class="card-body">
                        <blockquote class="card-bodyquote mb-0">
                            <p class="quick-links">School Album.</p>
                            
                            
                            
                        </blockquote>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-xl-3">
            <a href="<?php echo e(route('admin.welcome.message')); ?>">
                <div class="card m-b-30 text-white bg-danger">
                    <div class="card-body">
                        <blockquote class="card-bodyquote mb-0">
                            <p class="quick-links">School Message.</p>
                            
                            
                            
                        </blockquote>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-xl-3">
            <a href="<?php echo e(route('admin.about')); ?>">
                <div class="card m-b-30 text-white bg-warning">
                    <div class="card-body">
                        <blockquote class="card-bodyquote mb-0">
                            <p class="quick-links">Page Settings.</p>
                            
                            
                            
                        </blockquote>
                    </div>
                </div>
            </a>
        </div>
    </div>
    <!-- End Links-->

    <div class="row" id="gender-bargraph" style="display: none;">
        <div class="col-md-12">
            <div class="card m-b-30">
                <div class="card-body">
                    <h4 class="mt-0 header-title">Student By Grades</h4>

                    
                        
                            
                            
                        
                        
                            
                            
                        
                        
                            
                            
                        
                    
                    <div id="morris-bar-example" style="height: 300px"></div>
                </div>
            </div>
        </div>
    </div>

    
        
            
                
                    
                    
                        
                            
                                
                                    
                                    
                                    
                                    
                                    
                                    
                                

                            
                            
                                
                                    
                                    
                                    
                                    
                                    
                                    
                                
                                
                                    
                                    
                                    
                                    
                                    
                                    
                                
                                
                                    
                                    
                                    
                                    
                                    
                                    
                                
                                
                                    
                                    
                                    
                                    
                                    
                                    
                                
                                
                                    
                                    
                                    
                                    
                                    
                                    
                                
                                
                                    
                                    
                                    
                                    
                                    
                                    
                                
                                
                                    
                                    
                                    
                                    
                                    
                                    
                                

                            
                        
                    
                
            
        
    



<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

    <script>
        function get_bar_chart_data(){
            return $.ajax({
                url: '<?php echo e(route('admin.genderByClass')); ?>',
                contentType : false,
                processData : false,
                method: 'get',
                async: !1,
                // data: formData,
                success: function(result) {
                    console.log(result);
                    $('#gender-bargraph').show();
                },
                error: function (data) {
                    $('#gender-bargraph').hide();
                }
            });
        }
        !function ($) {
            "use strict";

            var Dashboard = function () {
            };
                //creates area chart
                Dashboard.prototype.createBarChart  = function(element, data, xkey, ykeys, labels, lineColors) {
                    Morris.Bar({
                        element: element,
                        data: data,
                        xkey: xkey,
                        ykeys: ykeys,
                        labels: labels,
                        gridLineColor: '#eef0f2',
                        barSizeRatio: 0.4,
                        resize: true,
                        hideHover: 'auto',
                        barColors: lineColors
                    });
                },

            Dashboard.prototype.init = function () {

                //creating bar chart
                var $barData = get_bar_chart_data().responseJSON;
                this.createBarChart('morris-bar-example', $barData, 'grade', ['male', 'female'], ['Male', 'Female'], [ '#fcc24c', '#54cc96']);

            },
                //init
                $.Dashboard = new Dashboard, $.Dashboard.Constructor = Dashboard
        }(window.jQuery),

//initializing
            function ($) {
                "use strict";
                $.Dashboard.init();
            }(window.jQuery);
    </script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>