

<?php $__env->startPush('styles'); ?>


<link href="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/css/select2.min.css" rel="stylesheet" />
<style>
    .select2-container {
        width: 100% !important;
        padding: 0;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('headers'); ?>

    
    <div class="row">
        <div class="col-sm-12">
            <div class="float-right page-breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#">Admin</a></li>
                    <li class="breadcrumb-item"><a href="#">Exam</a></li>
                    <li class="breadcrumb-item active">Index</li>
                </ol>
            </div>
            <h5 class="page-title"> <?php echo e(getLanguage('exam')); ?> </h5>
        </div>
    </div>
    <!-- end row -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>

    
    <div class="row">
        <div class="col-12">
            <div class="card m-b-30">
                <div class="card-body">


                    <h4 class="mt-0 header-title">
                        <?php echo e(getLanguage('exam').' '.getLanguage('list')); ?>

                        <button type="button" id="add_exam" class="btn btn-primary waves-effect waves-light float-right" data-toggle="modal" data-target=".edu-add-new">
                            <?php echo e(getLanguage('add-new').' '.getLanguage('exam')); ?>

                        </button>
                    </h4>
                        <?php echo $__env->make('admin.exam.add', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <div class="modal fade edu-edit-new" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
                    </div>

                    <div class="modal fade edu-result-new" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
                    </div>
                    <table id="datatable" class="table table-striped table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                        <thead>
                        <tr>
                            <th><?php echo e(getLanguage('serial')); ?></th>
                            <th><?php echo e(getLanguage('exam').' '.getLanguage('title')); ?></th>
                            <th><?php echo e(getLanguage('exam-start-date')); ?></th>
                            <th><?php echo e(getLanguage('grade')); ?></th>
                            <th><?php echo e(getLanguage('action')); ?></th>
                        </tr>
                        </thead>

                        <?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($exam->count); ?></td>
                                <td><?php echo e($exam->title); ?></td>
                                <td><?php echo e($exam->start_date); ?></td>
                                <td>

                                    <table width="100%" border="0" bgcolor="" cellspacing="0">
                                        <tr>
                                            <th>
                                                <?php echo e(getLanguage('grade')); ?>

                                            </th>
                                            <th>
                                                <?php echo e(getLanguage('action')); ?>

                                            </th>
                                        </tr>
                                        <?php if($exam->grades): ?>
                                            <?php $__currentLoopData = $exam->grades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td>
                                                        <?php echo e(getLanguage('grade')); ?> <?php echo e($grade->title); ?>

                                                    </td>
                                                    <td>
                                                        <button type='button'  class='btn btn-primary btn-icon-text mr-2 p-1 btn-result-row' grade-id="<?php echo e($grade->id); ?>" data-id="<?php echo e($exam->id); ?>"><i class=" mdi mdi-plus btn-icon-prepend"></i><?php echo e(getLanguage('result')); ?></button>
                                                        <?php if($exam->month >= 9): ?>
                                                        <a href='<?php echo e(route('admin.exam.pass.student', $grade->id)); ?>'  class='btn btn-success btn-icon-text mr-2 p-1'><i class=" mdi mdi-plus btn-icon-prepend"></i>Upgrade Student</a>
                                                            <?php endif; ?>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </table>

                                </td>
                                <td>
                                    <button type="button" id="edit_exam" class="btn btn-dark btn-icon-text mr-2 p-1 btn-edit-row" data-id="<?php echo e($exam->id); ?>" ><i class=" mdi mdi-grease-pencil btn-icon-prepend"></i><?php echo e(getLanguage('exam').' '.getLanguage('edit')); ?></button>
                                    <a href="<?php echo e(route('admin.exam.delete', $exam->id)); ?>" class="btn btn-danger btn-icon-text mr-2 p-1 btn-delete-row" data-id="1"><i class=" mdi mdi-delete btn-icon-prepend"></i><?php echo e(getLanguage('exam').' '.getLanguage('delete')); ?></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        <tbody>

                        </tbody>
                    </table>

                </div>
            </div>
        </div> <!-- end col -->
    </div> <!-- end row -->



<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>


<!-- Required datatable js -->
<script src="<?php echo e(asset('admin/assets/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/assets/plugins/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

<!-- Datatable init js -->
<script src="<?php echo e(asset('admin/assets/pages/datatables.init.js')); ?>"></script>



<script src="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js"></script>

<script>
    $(document).ready(function() {
        $('.js-example-basic-multiple').select2();
    });
</script>



<script>
    $(document).on("click", ".btn-edit-row", function (e) {
        e.preventDefault();
        $this = $(this);
        var id = $this.attr('data-id');

        var tempEditUrl = "<?php echo e(route('admin.exam.edit', ':id')); ?>";
        tempEditUrl = tempEditUrl.replace(':id', id);
        console.log(tempEditUrl);
        var $modal = $('.edu-edit-new');
        $modal.load(tempEditUrl, function (response) {
            $modal.modal('show');
        });
    });

</script>


<script>
    $(document).on("click", ".btn-result-row", function (e) {
        e.preventDefault();
        $this = $(this);
        var id = $this.attr('data-id');
        var grade_id = $this.attr('grade-id');

        var tempResultUrl = "<?php echo e(route('admin.exam.result', [':id', ':grade_id'])); ?>";
        tempResultUrl = tempResultUrl.replace(':id', id);
        tempResultUrl = tempResultUrl.replace(':grade_id', grade_id);
        console.log(tempResultUrl);
        var $modal = $('.edu-result-new');
        $modal.load(tempResultUrl, function (response) {
            $modal.modal('show');
        });
    });

</script>

<!-- <script>
     var mainInput =  $(".nepali-datepicker");
       
       /* Initialize Datepicker with options */
    mainInput.nepaliDatePicker({
        dateFormat: "MM/DD/YYYY"
    });
    
    var apple = NepaliFunctions.GetCurrentBsDate();
    console.log(NepaliFunctions.ConvertDateFormat(apple, "MM/DD/YYYY"))
</script> -->



<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>