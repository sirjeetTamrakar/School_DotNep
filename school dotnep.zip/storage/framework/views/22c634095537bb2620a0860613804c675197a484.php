

<?php $__env->startPush('styles'); ?>


    <!-- Dropzone css -->
    
    <style>
        .image_preview{
            width: 100%;
            min-height: 100px;
            margin-top: 15px;

            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            color: #cccccc;

        }

        .image_preview img{
            width: 150px;
            height: auto;
        }
    </style>


<?php $__env->stopPush(); ?>

<?php $__env->startSection('headers'); ?>

    
    <div class="row">
        <div class="col-sm-12">
            <div class="float-right page-breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Admin</a></li>
                    <li class="breadcrumb-item "><a href="<?php echo e(route('admin.staff.all')); ?>">Staffs</a></li>
                    <li class="breadcrumb-item "><a href="<?php echo e(route('admin.staff.details',$staff->slug)); ?>"><?php echo e($staff->name); ?></a></li>
                    <li class="breadcrumb-item active"><a href="<?php echo e(route('admin.staff.edit',$staff->slug)); ?>">Info</a></li>
                </ol>
            </div>
            <h5 class="page-title"><?php echo e(getLanguage('staff').' '.getLanguage('edit')); ?></h5>
        </div>
    </div>
    <!-- end row -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>

    
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="modal-title" id="exampleModalLabel"><?php echo e($staff->name); ?>&nbsp;: <?php echo e(getLanguage('detail')); ?></h4>

                    <form method="post" action="<?php echo e(route('admin.staff.update',$staff->slug)); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <h5 class="text-center"><?php echo e(getLanguage('basic-info')); ?></h5>
                        <div class="row">
                            <div class="col-md-8">
                                <div class="form-group">
                                    <label for="name"><?php echo e(getLanguage('name')); ?></label>
                                    <input type="text" name="name" value="<?php echo e($staff->name); ?>" id="name" class="form-control" required>
                                </div>
                                <div class="form-group">
                                    <label for="title"><?php echo e(getLanguage('job-title')); ?>:</label>
                                    <textarea name="job_title" id="title" class="form-control"><?php echo e($staff->job_title); ?></textarea>
                                </div>

                                <div class="form-group">
                                    <label for="staff_type"><?php echo e(getLanguage('stafftype')); ?>:</label>
                                    <select name="staff_type_id" id="staff_type" class="form-control" required>
                                        <option value="" selected disabled="disabled">Select a staff type</option>
                                        <?php $__currentLoopData = $staff_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($staff_type->id); ?>"
                                                    <?php if($staff_type->id==$staff->staff_type_id): ?> selected <?php endif; ?>
                                            >
                                                <?php echo e($staff_type->title); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="phone"><?php echo e(getLanguage('phone')); ?>:</label>
                                    <input type="text" name="phone" value="<?php echo e($staff->phone); ?>" id="phone" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label for="email"><?php echo e(getLanguage('phone')); ?>:</label>
                                    <input type="text" name="email" value="<?php echo e($staff->email); ?>" id="email" class="form-control">
                                </div>

                                <div class="form-group">
                                    <label for="ethnicity"><?php echo e(getLanguage('address')); ?>:</label>
                                    <textarea name="address" id="address" class="form-control"><?php echo e($staff->address); ?></textarea>
                                </div>

                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="gender"><?php echo e(getLanguage('gender')); ?>:</label>
                                    <select name="gender" id="gender" class="form-control" required>
                                        <option value="Male"
                                                <?php if("Male"==$staff->gender): ?> selected <?php endif; ?>
                                        >Male</option>
                                        <option value="Female"
                                                <?php if("Female"==$staff->gender): ?> selected <?php endif; ?>
                                        >Female</option>
                                        <option value="Other"
                                                <?php if("Other"==$staff->gender): ?> selected <?php endif; ?>
                                        >Other</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="DOB"><?php echo e(getLanguage('birth-date')); ?>:</label>
                                    <input type="text" name="DOB" value="<?php echo e($staff->DOB); ?>" id="DOB" class="form-control nepali-calendar">
                                </div>
                                <div class="form-group">
                                    <label for="DOB"><?php echo e(getLanguage('join-date')); ?>:</label>
                                    <input type="text" name="join_date" value="<?php echo e($staff->join_date); ?>" id="join_date" class="form-control nepali-calendar" >
                                </div>
                                <div class="form-group">
                                    <label for="photo"><?php echo e(getLanguage('image')); ?></label>
                                    <input type="file" name="image" id="photo" class="form-control">
                                </div>
                                <div class="image_preview">
                                    <img src="
                                            <?php if(isset($staff->image)): ?>
                                                <?php echo e(asset($staff->image)); ?>

                                            <?php else: ?>
                                                <?php echo e(asset('admin/img/profile_icon.png')); ?>

                                            <?php endif; ?>"
                                         alt="" id="preview_image" name style="height: 100px; width: auto">
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label><?php echo e(getLanguage('staff').' '.getLanguage('description')); ?></label>
                                    <textarea name="description" class="summernote form-control"><?php echo e($staff->description); ?></textarea>
                                </div>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-success pull-right">Save changes</button>
                    </form>
                </div>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>


    <!-- Dropzone js -->
    


<script>
    $('input[type=file]').on('change', function(e){
        uploadimages(e)
    });

    function uploadimages(e){
        const file = e.target.files[0];
        if(file){
            const reader = new FileReader();
            reader.addEventListener('load',function(){
                const previewImage = document.querySelector('#preview_image')
                console.log(previewImage)
                previewImage.setAttribute("src",reader.result)
            });
            reader.readAsDataURL(file);
        }
    }
</script>



<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>