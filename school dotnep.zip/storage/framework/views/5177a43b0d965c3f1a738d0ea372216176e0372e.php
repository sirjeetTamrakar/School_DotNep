

<?php $__env->startPush('style'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

    <div class="sub-banner">
        <div class="img-container">
            <img src="<?php echo e(asset(isset($settings['bannerImage']) ? $settings['bannerImage']: "")); ?>" alt="" />
            <div class="overlay">
                <div class="title">
                    Message
                </div>
            </div>
        </div>
    </div>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('front.home')); ?>">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">
                Principal Note
            </li>
        </ol>
    </nav>
    <div class="mission-section">
        <div class="container m-b-30">
            <div class="row">
                <div class="col-md-5">
                    <div class="img-container">
                        <img src="<?php echo e(asset(isset($settings['principal_image']) ? 'thumbnail/'.$settings['principal_image']: 'front/assets/images/about.jpg')); ?>" alt="" class="img-fluid" />
                    </div>
                </div>
                <div class="col-md-7">
                    <div class="mission-title">
                        Message From Principal
                    </div>
                    <div class="mission-detail">
                        <?php echo isset($settings['principal_message']) ? $settings['principal_message']: ''; ?>

                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-md-5">
                    <div class="img-container">
                        <img src="<?php echo e(asset(isset($settings['adhyaksh_image']) ? 'thumbnail/'.$settings['adhyaksh_image']: 'front/assets/images/about.jpg')); ?>" alt="" class="img-fluid" />
                    </div>
                </div>
                <div class="col-md-7">
                    <div class="mission-title">
                        Message From Adhyaksha
                    </div>
                    <div class="mission-detail">
                        <?php echo isset($settings['adhyaksh_message']) ? $settings['adhyaksh_message']: ''; ?>

                    </div>
                </div>
            </div>
        </div>
            
                
            
            
                
                    
                    
                    
                    
                    
                    
                    
                    
                
                
                    
                    
                    
                    
                    
                    
                    
                    
                
            
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('front.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>