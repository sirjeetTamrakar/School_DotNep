

<?php $__env->startPush('styles'); ?>


    <style>
        .emp-profile{
            padding: 3%;
            margin-top: 3%;
            margin-bottom: 3%;
            border-radius: 0.5rem;
            background: #fff;
        }
        .profile-img{
            text-align: center;
        }
        .profile-img img{
            width: 70%;
            height: 100%;
        }
        .profile-img .file {
            position: relative;
            overflow: hidden;
            margin-top: -20%;
            width: 70%;
            border: none;
            border-radius: 0;
            font-size: 15px;
            background: #212529b8;
        }
        .profile-img .file input {
            position: absolute;
            opacity: 0;
            right: 0;
            top: 0;
        }
        .profile-head h5{
            color: #333;
        }
        .profile-head h6{
            color: #0062cc;
        }
        .profile-edit-btn{
            border: none;
            border-radius: 1.5rem;
            width: 70%;
            padding: 2%;
            font-weight: 600;
            color: #6c757d;
            cursor: pointer;
        }
        .proile-rating{
            font-size: 12px;
            color: #818182;
            margin-top: 5%;
        }
        .proile-rating span{
            color: #495057;
            font-size: 15px;
            font-weight: 600;
        }
        .profile-head .nav-tabs{
            margin-bottom:5%;
        }
        .profile-head .nav-tabs .nav-link{
            font-weight:600;
            border: none;
        }
        .profile-head .nav-tabs .nav-link.active{
            border: none;
            border-bottom:2px solid #0062cc;
        }
        .profile-work{
            padding: 14%;
            margin-top: -15%;
        }
        .profile-work p{
            font-size: 12px;
            color: #818182;
            font-weight: 600;
            margin-top: 10%;
        }
        .profile-work a{
            text-decoration: none;
            color: #495057;
            font-weight: 600;
            font-size: 14px;
        }
        .profile-work ul{
            list-style: none;
        }
        .profile-tab label{
            font-weight: 600;
        }
        .profile-tab p{
            font-weight: 600;
            color: #0062cc;
        }

        .image_preview{
            width: 300px;
            min-height: 100px;
            border: 2px solid #dddddd;
            margin-top: 15px;

            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            color: #cccccc;

        }

        .image_preview_image{
            height: 150px;
            width: auto;
        }
        .nav {
            margin-top: 60px;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('headers'); ?>

    
    <div class="row">
        <div class="col-sm-12">
            <div class="float-right page-breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Admin</a></li>
                    <li class="breadcrumb-item "><a href="<?php echo e(route('admin.staff.all')); ?>">Staffs</a></li>
                    <li class="breadcrumb-item active"><a href="<?php echo e(route('admin.staff.details',$staff->slug)); ?>"><?php echo e($staff->name); ?></a></li>
                </ol>
            </div>
            <h5 class="page-title"><?php echo e(getLanguage('staff')); ?> <?php echo e(getLanguage('profile')); ?></h5>
        </div>
    </div>
    <!-- end row -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>

    
    <div class="container emp-profile">
        <form method="post">
            <div class="row">
                <div class="col-md-4">
                    <div class="profile-img">
                        <img src="
                            <?php if(isset($staff->image)): ?>
                            <?php echo e(asset($staff->image)); ?>

                            <?php else: ?>
                            <?php echo e(asset('admin/img/profile_icon.png')); ?>

                            <?php endif; ?>" alt=""/>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="profile-head">
                        <h5>
                            <?php echo e($staff->name); ?>

                        </h5>
                        <h6>
                            <?php echo e($staff->staffType->title); ?>

                        </h6>
                        <p><?php echo e($staff->staffType->remarks); ?></p>
                        
                        <ul class="nav nav-tabs" id="myTab" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true"><?php echo e(getLanguage('about')); ?></a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="profile-tab" data-toggle="tab" href="#experience" role="tab" aria-controls="profile" aria-selected="false"><?php echo e(getLanguage('qualifications')); ?></a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="profile-tab" data-toggle="tab" href="#certificate" role="tab" aria-controls="profile" aria-selected="false"><?php echo e(getLanguage('certificates')); ?></a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-2">
                    <ul class="nav navbar-nav">
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle profile-edit-btn" data-toggle="dropdown"><?php echo e(getLanguage('edit')); ?><b class="caret"></b></a>
                            <ul class="dropdown-menu">
                                <li><a href="<?php echo e(route('admin.staff.edit',$staff->slug)); ?>">
                                        <?php echo e(getLanguage('basic-info').' '.getLanguage('edit')); ?></a>
                                </li>
                                <li><a href="<?php echo e(route('admin.staff.qualifications',$staff->slug)); ?>">
                                        <?php echo e(getLanguage('qualifications').' '.getLanguage('edit')); ?></a>
                                </li>
                                <li><a href="<?php echo e(route('admin.staff.certificates',$staff->slug)); ?>">
                                        <?php echo e(getLanguage('certificates').' '.getLanguage('edit')); ?></a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                    
                        
                    
                </div>
            </div>
            <div class="row">
                <div class="col-md-4">
                    <div class="profile-work">

                    </div>
                </div>
                <div class="col-md-8">
                    <div class="tab-content profile-tab" id="myTabContent">
                        <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                            <div class="row">
                                <div class="col-md-6">
                                    <label><?php echo e(getLanguage('job-title')); ?></label>
                                </div>
                                <div class="col-md-6">
                                    <p><?php echo e($staff->job_title); ?></p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <label><?php echo e(getLanguage('ethnicity')); ?></label>
                                </div>
                                <div class="col-md-6">
                                    <?php if(isset($staff->ethnicity)): ?>
                                    <p><?php echo e($staff->ethnicity->title); ?></p>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <label><?php echo e(getLanguage('gender')); ?></label>
                                </div>
                                <div class="col-md-6">
                                    <p><?php echo e($staff->gender); ?></p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <label><?php echo e(getLanguage('phone')); ?></label>
                                </div>
                                <div class="col-md-6">
                                    <p><?php echo e($staff->phone); ?></p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <label><?php echo e(getLanguage('birth-date')); ?></label>
                                </div>
                                <div class="col-md-6">
                                    <p><?php echo e($staff->DOB); ?></p>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <label><?php echo e(getLanguage('address')); ?></label>
                                </div>
                                <div class="col-md-6">
                                    <p><?php echo e($staff->address); ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="experience" role="tabpanel" aria-labelledby="profile-tab">
                            <div class="table-rep-plugin">
                                <div class="table-responsive b-0" data-pattern="priority-columns">
                                    <table id="tech-companies-1" class="table  table-striped">
                                        <thead>
                                        <tr>
                                            <th data-priority="1"><?php echo e(getLanguage('serial')); ?></th>
                                            <th data-priority="4"><?php echo e(getLanguage('organization-s-name')); ?></th>
                                            <th data-priority="3"><?php echo e(getLanguage('job-title')); ?></th>
                                            <th data-priority="1"><?php echo e(getLanguage('job-location')); ?></th>
                                            <th data-priority="3"><?php echo e(getLanguage('job-start-date')); ?></th>
                                            <th data-priority="3"><?php echo e(getLanguage('job-end-date')); ?></th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <?php if(isset($staff->expriences)): ?>
                                                <?php $count=1; ?>
                                                <?php $__currentLoopData = $staff->expriences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <td><?php echo e($count); ?></td>
                                                    <td><?php echo e($exp->organization_name); ?></td>
                                                    <td><?php echo e($exp->job_title); ?></td>
                                                    <td><?php echo e($exp->job_location); ?></td>
                                                    <td><?php echo e($exp->start_date); ?></td>
                                                    <td><?php echo e($exp->end_date); ?></td>
                                                <?php $count++; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="certificate" role="tabpanel" aria-labelledby="profile-tab">
                            <div class="row">
                                <?php if(isset($staff->documents)): ?>
                                    <?php $__currentLoopData = $staff->documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-4 ">
                                        <div class="card" style="box-shadow: 5px 10px 6px #888888;">
                                            <div class="card-header text-center">
                                                <a href="<?php echo e(asset($doc->file)); ?>">
                                                <span><?php echo e($doc->title); ?></span>
                                                </a>
                                            </div>
                                            <div class="card-body">
                                                <a href="<?php echo e(asset($doc->file)); ?>">
                                                <img class="image_preview_image" src="<?php echo e(asset('admin/img/document_logo.png')); ?>" alt="">
                                                </a>
                                            </div>
                                        </div>
                                        
                                            
                                            
                                        
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>


<script>
    $('ul.nav li.dropdown').hover(function() {
        $(this).find('.dropdown-menu').stop(true, true).delay(200).fadeIn(500);
    }, function() {
        $(this).find('.dropdown-menu').stop(true, true).delay(200).fadeOut(500);
    });
</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>