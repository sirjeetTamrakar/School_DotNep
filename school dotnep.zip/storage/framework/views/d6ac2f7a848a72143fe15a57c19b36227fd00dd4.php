
    <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title text-center" id="exampleModalLabel"><?php echo e(getLanguage('message')); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6">
                            <strong><?php echo e(getLanguage('name')); ?></strong>
                        </div>
                        <div class="col-md-6">
                            <strong><?php echo e($content->name); ?></strong>
                        </div>
                    </div>
                    <hr><hr>
                    <div class="row">
                        <div class="col-md-6">
                            <strong><?php echo e(getLanguage('email')); ?></strong>
                        </div>
                        <div class="col-md-6">
                            <strong><?php echo e($content->email); ?></strong>
                        </div>
                    </div>
                    <hr><hr>
                    <div class="row">
                        <div class="col-md-6">
                            <strong><?php echo e(getLanguage('phone')); ?></strong>
                        </div>
                        <div class="col-md-6">
                            <strong><?php echo e($content->phone); ?></strong>
                        </div>
                    </div>
                    <hr><hr>
                    <div class="row">
                        <div class="col-md-6">
                            <strong><?php echo e(getLanguage('subject')); ?></strong>
                        </div>
                        <div class="col-md-6">
                            <strong><?php echo e($content->subject); ?></strong>
                        </div>
                    </div>
                    <hr><hr>
                    <div class="row">
                        <div class="col-md-6">
                            <strong><?php echo e(getLanguage('message')); ?></strong>
                        </div>
                        <div class="col-md-6">
                            <strong><?php echo e($content->message); ?></strong>
                        </div>
                    </div>
                    <hr><hr>

                    <div class="row">
                        <div class="col-md-2">
                            <strong>Content:</strong>
                        </div>
                        <div class="col-md-10">
                            <p><?php echo $content->message; ?></p>
                        </div>
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </form>
    </div>
