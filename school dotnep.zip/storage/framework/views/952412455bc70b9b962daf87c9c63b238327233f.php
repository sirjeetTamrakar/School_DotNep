

<?php $__env->startPush('styles'); ?>



<?php $__env->stopPush(); ?>

<?php $__env->startSection('headers'); ?>

    
    <div class="row">
        <div class="col-sm-12">
            <div class="float-right page-breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#">Admin</a></li>
                    <li class="breadcrumb-item"><a href="#">School</a></li>
                    <li class="breadcrumb-item active">Add</li>
                </ol>
            </div>
            <h5 class="page-title"><?php echo e(getLanguage('basic-info')); ?></h5>
        </div>
    </div>
    <!-- end row -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>

    
    <div class="row">
        <div class="col-12">
            <div class="card m-b-30">
                <div class="card-body">

                    <h4 class="mt-0 header-title"><?php echo e(getLanguage('school').' '.getLanguage('information-1')); ?></h4>


                    <form class="" action="<?php echo e(route('admin.about.update')); ?>" method="post" enctype="multipart/form-data">

                        <?php echo e(csrf_field()); ?>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label><?php echo e(getLanguage('school').' '.getFrontLanguage('name')); ?></label>
                                    <input type="text" value="<?php echo e(getAbout('name')); ?>" name="name" class="form-control" required placeholder="School Name"/>
                                </div>


                                <div class="form-group">
                                    <label><?php echo e(getLanguage('school').' '.getLanguage('description')); ?></label>
                                    <textarea type="text" value="<?php echo e(getAbout('description')); ?>" name="description" class="form-control" > </textarea>
                                </div>



                                <div class="form-group">
                                    <label for="photo"><?php echo e(getLanguage('school').' '.getLanguage('logo')); ?></label>
                                    <input type="file" name="logo" id="logo" class="form-control">
                                    <div class="image_preview">
                                        <div class="z-depth-1-half mb-4" style="text-align: center;">
                                            <img style="width: 100px;" id="preview_logo" src="<?php echo e(asset('thumbnail/'.getAbout('logo'))); ?>" class="avatar-pic img-fluid" title="Click To Upload news Photo"
                                                 alt="news Image">
                                        </div>
                                    </div>
                                </div>



                                <div class="form-group">
                                    <label for="photo"><?php echo e(getLanguage('school').' '.getLanguage('favicon')); ?></label>
                                    <input type="file" name="favicon" id="favicon" class="form-control">
                                    <div class="image_preview">
                                        <div class="z-depth-1-half mb-4" style="text-align: center;">
                                            <img style="width: 100px;" id="preview_favicon" src="<?php echo e(asset('thumbnail/'.getAbout('favicon'))); ?>" class="avatar-pic img-fluid" title="Click To Upload news Photo"
                                                 alt="news Image">
                                        </div>
                                    </div>
                                </div>


                                <div class="form-group">
                                    <label><?php echo e(getLanguage('facebook').' '.getLanguage('link')); ?></label>
                                    <input type="text"  value="<?php echo e(getAbout('facebook_link')); ?>" name="facebook_link" class="form-control" required placeholder="Facebook Link "/>
                                </div>


                                <div class="form-group">
                                    <label><?php echo e(getLanguage('youtube').' '.getLanguage('link')); ?></label>
                                    <input type="text"  value="<?php echo e(getAbout('youtube_link')); ?>" name="youtube_link" class="form-control" required placeholder="Youtube Link "/>
                                </div>


                                <div class="form-group">
                                    <label><?php echo e(getLanguage('twitter').' '.getLanguage('link')); ?></label>
                                    <input type="text"  value="<?php echo e(getAbout('twitter_link')); ?>" name="twitter_link" class="form-control" required placeholder="Twitter Link "/>
                                </div>

                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label><?php echo e(getLanguage('school').' '.getLanguage('address')); ?></label>
                                    <input type="text" name="address"  value="<?php echo e(getAbout('address')); ?>" class="form-control" required placeholder="Address"/>
                                </div>

                                <div class="form-group">
                                    <label><?php echo e(getLanguage('school').' '.getLanguage('phone')); ?></label>
                                    <input type="text" name="phone"  value="<?php echo e(getAbout('phone')); ?>" class="form-control" placeholder="Phone Number"/>
                                </div>

                                <div class="form-group">
                                    <label><?php echo e(getLanguage('school').' '.getLanguage('email')); ?></label>
                                    <input type="email" name="email"  value="<?php echo e(getAbout('email')); ?>" class="form-control" placeholder="Email"/>
                                </div>

                                <div class="form-group">
                                    <label><?php echo e(getLanguage('province-number')); ?></label>
                                    <input type="number" name="province_number"  value="<?php echo e(getAbout('province_number')); ?>" class="form-control" placeholder="Province Number"/>
                                </div>
                                <div class="form-group">
                                    <label><?php echo e(getLanguage('vdc-municipality-name')); ?></label>
                                    <input type="text" name="vdc_name"  value="<?php echo e(getAbout('vdc_name')); ?>" class="form-control" placeholder="Name"/>
                                </div>
                                <div class="form-group">
                                    <label><?php echo e(getLanguage('vdc-municipality-address')); ?></label>
                                    <input type="text" name="vdc_address"  value="<?php echo e(getAbout('vdc_address')); ?>" class="form-control" placeholder="Address"/>
                                </div>
                                <div class="form-group">
                                    <label><?php echo e(getLanguage('vdc-municipality-phone')); ?></label>
                                    <input type="text" name="vdc_phone"  value="<?php echo e(getAbout('vdc_phone')); ?>" class="form-control" placeholder="Phone"/>
                                </div>





                                <div class="form-group">
                                    <label for="photo"><?php echo e(getLanguage('vdc-municipality-logo')); ?></label>
                                    <input type="file" name="vdc_logo" id="vdc" class="form-control">
                                    <div class="image_preview">
                                        <div class="z-depth-1-half mb-4" style="text-align: center;">
                                            <img style="width: 100px;" id="preview_vdc" src="<?php echo e(asset('thumbnail/'.getAbout('vdc_logo'))); ?>" class="avatar-pic img-fluid" title="Click To Upload news Photo"
                                                 alt="news Image">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <button type="submit" class="btn btn-success waves-effect waves-light float-right">Update</button>
                    </form>

                </div>
            </div>
        </div> <!-- end col -->
    </div> <!-- end row -->



<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

<!-- Required datatable js -->
<script>
    $('input[type=file]').on('change', function(e){
        $this = $(this);
        uploadimages(e, this)
    });

    function uploadimages(e){
        const file = e.target.files[0];
        if(file){
            const reader = new FileReader();
            reader.addEventListener('load',function(){

                const previewImage = document.querySelector('#preview_'+e.target.id)
                console.log(previewImage)
                previewImage.setAttribute("src",reader.result)
            });
            reader.readAsDataURL(file);
        }
    }
</script>


<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>