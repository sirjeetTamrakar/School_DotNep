

<?php $__env->startPush('style'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>


    <div class="sub-banner">
        <div class="img-container">
            <img src="<?php echo e(asset(isset($settings['bannerImage'])?$settings['bannerImage']:'')); ?>" alt="" />
            <div class="overlay">
                <div class="title">
                    <?php echo e(getFrontLanguage('result-1')); ?>

                </div>
            </div>
        </div>
    </div>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('front.home')); ?>"><?php echo e(getFrontLanguage('home')); ?></a></li>
            <li class="breadcrumb-item active" aria-current="page">
                <?php echo e(getFrontLanguage('result-1')); ?>

            </li>
        </ol>
    </nav>
    <div class="result-section">
        <div class="container">
            <ul class="nav nav-tabs">
                <?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="nav-item">
                        <a class="nav-link <?php if($exams[0]->id == $exam->id): ?> active <?php endif; ?>" data-toggle="tab" href="#term<?php echo e($exam->id); ?>">
                            <?php echo e($exam->title); ?>

                        </a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>

            <!-- Tab panes -->
            <div class="tab-content mb-5">
                <?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="tab-pane <?php if($exams[0]->id == $exam->id): ?> active <?php endif; ?> " id="term<?php echo e($exam->id); ?>">
                        <table class="table  table-bordered table-striped table-hover">
                            <thead class="bg-primary">
                            <tr>
                                <th><?php echo e(getFrontLanguage('serial')); ?></th>
                                <th><?php echo e(getFrontLanguage('class-1')); ?></th>
                                <th><?php echo e(getFrontLanguage('download-1')); ?></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $counter=1; ?>
                            <?php $__currentLoopData = $exam->grades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($counter); ?></td>
                                    <td><?php echo e(getFrontLanguage('class-1')); ?> <?php echo e($grade->title); ?></td>
                                    <td>
                                        <?php if($result = $grade->results->where('exam_id',$exam->id)->first()): ?>
                                            <a href="<?php echo e(asset($result->file)); ?>" target="_blank"><i class="fa fa-download"></i></a>
                                        <?php else: ?>
                                            No result
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php $counter++; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('front.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>