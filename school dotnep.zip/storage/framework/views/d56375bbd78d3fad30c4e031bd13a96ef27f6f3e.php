

<?php $__env->startPush('styles'); ?>

    <style>
        .calendar{
            margin: 30px 30px auto;
            text-align: center;
        }
    </style>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('headers'); ?>

    
    <div class="row">
        <div class="col-sm-12">
            <div class="float-right page-breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#">Admin</a></li>
                    <li class="breadcrumb-item"><a href="#">Students</a></li>
                    <li class="breadcrumb-item active">Index</li>
                </ol>
            </div>
            <h5 class="page-title"> <?php echo e(getLanguage('students')); ?> </h5>
        </div>
    </div>
    <!-- end row -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>

    
    <div class="row">
        <div class="col-12">
            <div class="card m-b-30">
                <div class="card-body">

                    <h4 class="mt-0 header-title"><?php echo e(getLanguage('select')); ?> <?php echo e(getLanguage('grade')); ?><a href="<?php echo e(route('admin.student.create')); ?>" class="btn btn-primary waves-effect waves-light float-right"><?php echo e(getLanguage('add-new')); ?> <?php echo e(getLanguage('student')); ?></a></h4>

                    <div class="row">
                        <div class="col-md-8 offset-md-2">
                            <div class="row">
                                <?php $__currentLoopData = $grades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-sm-3">
                                        <div class="form-group">
                                            <a class="btn btn-primary" href="<?php echo e(route('admin.students', $grade->id)); ?>"><?php echo e($grade->title); ?></a>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div> <!-- end col -->
    </div> <!-- end row -->

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="calendar">
                        <iframe src="https://www.hamropatro.com/widgets/calender-full.php" frameborder="0" scrolling="no" marginwidth="0" marginheight="0"
                                style="border:none; overflow:hidden; width:800px; height:840px;" allowtransparency="true"></iframe>
                    </div>
                </div>
            </div>
        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>