<div class="slim-navbar">
    <div class="container slim-wrapper">
        <div class="phone">
            <i class="fa fa-phone"></i> Phone: <?php echo e(isset($settings['phone']) ? $settings['phone'] : ""); ?>, <?php echo e(isset($settings['vdc_phone']) ? $settings['vdc_phone'] : ""); ?>

        </div>
        <div class="social-link">
            <i class="fab fa-facebook"></i> Facebook |
            <i class="fab fa-twitter"></i> Twitter
        </div>
    </div>
</div>
<div id="navbar">
    <div class="container d-flex justify-content-between">
        <div class="right-container">
            <div class="logo">
                <img
                        src="<?php echo e(asset(isset($settings['logo']) ? $settings['logo'] : "front/assets/images/logo.png")); ?>"
                        alt="" class="img-fluid" />
            </div>
            <div class="center-container">
                <div class="company_name"><?php echo e(isset($settings['name']) ? $settings['name'] : "High School"); ?></div>
                <div class="company_address">
                    <?php echo e(isset($settings['address']) ? $settings['address'] : ""); ?>

                </div>
            </div>
        </div>

        <div class="right-container d-none d-md-flex">
            <div class="ministry">
                <div class="company_province"><?php echo e(getFrontLanguage('province-no')); ?>. <?php echo e(isset($settings['province_number']) ? $settings['province_number'] :""); ?></div>
                <div class="company_ministry">
                    <?php echo e(isset($settings['vdc_name']) ? $settings['vdc_name'] : "Ministry of Education"); ?><br />
                    <?php echo e(isset($settings['vdc_address']) ? $settings['vdc_address'] : "Science And Technology"); ?>

                </div>
            </div>
            <div class="logo">
                <img
                        src="<?php echo e(asset(isset($settings['vdc_logo']) ? $settings['vdc_logo'] : "front/assets/images/logo.png")); ?>"
                        alt="" class="img-fluid" />
            </div>
        </div>
    </div>
</div>

<div id="myNav" class="overlay">
    <a class="closebtn" onclick="closeNav()">
        &times;
    </a>

    <div class="overlay-content">
        <a href="<?php echo e(route('front.home')); ?>"><?php echo e(getFrontLanguage('home')); ?></a>

        <div class="dropdown">
            <button class="dropbtn">
                <?php echo e(getFrontLanguage('school-overview')); ?> <i class="fa fa-caret-down"></i>
            </button>
            <div class="dropdown-content">
                <a href="<?php echo e(route('front.about')); ?>"><?php echo e(getFrontLanguage('about-us')); ?></a>
                
                <a href="<?php echo e(route('front.principal-note')); ?>"><?php echo e(getFrontLanguage('administration-note')); ?></a>
                <a href="<?php echo e(route('front.gallery')); ?>"><?php echo e(getFrontLanguage('gallery')); ?></a>
            </div>
        </div>

        
            
                
            
            
                    
                        
                    
            
        
        <div class="dropdown">
            <button class="dropbtn">
                <?php echo e(getFrontLanguage('members-enrolled')); ?> <i class="fa fa-caret-down"></i>
            </button>
            <div class="dropdown-content">
                <?php $__currentLoopData = get_staff_types(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('front.staffs',$type->slug)); ?>"><?php echo e($type->title); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <a href="<?php echo e(route('front.students')); ?>"><?php echo e(getFrontLanguage('student-detail')); ?></a>
        <div class="dropdown">
            <button class="dropbtn">
                <?php echo e(getFrontLanguage('information')); ?> <i class="fa fa-caret-down"></i>
            </button>
            <div class="dropdown-content">
                <a href="<?php echo e(route('front.notice')); ?>"><?php echo e(getFrontLanguage('notice-1')); ?></a>
                <a href="<?php echo e(route('front.news')); ?>"><?php echo e(getFrontLanguage('news-1')); ?></a>
                <a href="<?php echo e(route('front.events')); ?>"><?php echo e(getFrontLanguage('event')); ?></a>
                <a href="<?php echo e(route('front.tender')); ?>"><?php echo e(getFrontLanguage('tender-1')); ?></a>
                <a href="<?php echo e(route('front.download')); ?>"><?php echo e(getFrontLanguage('download')); ?></a>
            </div>
        </div>
        <a href="<?php echo e(route('front.calendar')); ?>"><?php echo e(getFrontLanguage('calendar')); ?></a>
        <div class="dropdown">
            <button class="dropbtn">
                <?php echo e(getFrontLanguage('result-1')); ?> <i class="fa fa-caret-down"></i>
            </button>
            <div class="dropdown-content">
                <?php $__currentLoopData = get_result_years(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result_year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('front.result',$result_year)); ?>"><?php echo e($result_year); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <a href="<?php echo e(route('front.contact')); ?>"><?php echo e(getFrontLanguage('contact-us')); ?></a>
    </div>
</div>
<div id="secondNavbar" class="d-none  d-lg-block">
    <div class="container ">
        <div class="nav  d-flex justify-content-around">
            <a href="<?php echo e(route('front.home')); ?>"><?php echo e(getFrontLanguage('home')); ?></a>

            <div class="dropdown">
                <button class="dropbtn">
                    <?php echo e(getFrontLanguage('school-overview')); ?> <i class="fa fa-caret-down"></i>
                </button>
                <div class="dropdown-content">
                    <a href="<?php echo e(route('front.about')); ?>"><?php echo e(getFrontLanguage('about-us')); ?></a>

                    <a href="<?php echo e(route('front.principal-note')); ?>"><?php echo e(getFrontLanguage('administration-note')); ?></a>
                    <a href="<?php echo e(route('front.gallery')); ?>"><?php echo e(getFrontLanguage('gallery')); ?></a>
                </div>
            </div>

            
                
                    
                
                
                    
                        
                    
                
            
            <div class="dropdown">
                <button class="dropbtn">
                    <?php echo e(getFrontLanguage('members-enrolled')); ?> <i class="fa fa-caret-down"></i>
                </button>
                <div class="dropdown-content">
                    <?php $__currentLoopData = get_staff_types(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('front.staffs',$type->slug)); ?>"><?php echo e($type->title); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <a href="<?php echo e(route('front.students')); ?>"><?php echo e(getFrontLanguage('student-detail')); ?></a>

            <div class="dropdown">
                <button class="dropbtn">
                    <?php echo e(getFrontLanguage('information')); ?> <i class="fa fa-caret-down"></i>
                </button>
                <div class="dropdown-content">
                    <a href="<?php echo e(route('front.notice')); ?>"><?php echo e(getFrontLanguage('notice-1')); ?></a>
                    <a href="<?php echo e(route('front.news')); ?>"><?php echo e(getFrontLanguage('news-1')); ?></a>
                    <a href="<?php echo e(route('front.events')); ?>"><?php echo e(getFrontLanguage('event')); ?></a>
                    <a href="<?php echo e(route('front.tender')); ?>"><?php echo e(getFrontLanguage('tender-1')); ?></a>
                    <a href="<?php echo e(route('front.download')); ?>"><?php echo e(getFrontLanguage('download')); ?></a>
                </div>
            </div>
            <a href="<?php echo e(route('front.calendar')); ?>"><?php echo e(getFrontLanguage('calendar')); ?></a>
            <div class="dropdown">
                <button class="dropbtn">
                    <?php echo e(getFrontLanguage('result-1')); ?> <i class="fa fa-caret-down"></i>
                </button>
                <div class="dropdown-content">
                    <?php $__currentLoopData = get_result_years(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result_year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('front.result',$result_year)); ?>"><?php echo e($result_year); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <a href="<?php echo e(route('front.contact')); ?>"><?php echo e(getFrontLanguage('contact-us')); ?></a>
            <form method="post" action="<?php echo e(route('front.setLanguage')); ?>">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                    <select name="language" class="frontselectlanguage">
                        <option value="nep" <?php if(\Session::get('front_lang_session') == "nep"): ?> selected <?php endif; ?>>Nep</option>
                        <option value="eng" <?php if(\Session::get('front_lang_session') == "eng"): ?> selected <?php endif; ?>>Eng</option>
                    </select>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="top-navbar">
    <div class="container d-flex justify-content-between">
				<span onclick="openNav()" class="d-block d-lg-none">
					<i class="fa fa-bars"></i>
				</span>

        <form method="post" action="<?php echo e(route('front.setLanguage')); ?>" class="d-block d-lg-none">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <select name="language" class="frontselectlanguage">
                    <option value="nep" <?php if(\Session::get('front_lang_session') == "nep"): ?> selected <?php endif; ?>>Nep</option>
                    <option value="eng" <?php if(\Session::get('front_lang_session') == "eng"): ?> selected <?php endif; ?>>Eng</option>
                </select>
            </div>
        </form>
    </div>
</div>