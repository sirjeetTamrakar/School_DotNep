
<div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title mt-0"><?php echo e(getLanguage('result')); ?> : <?php echo e(getLanguage('date')); ?> "<?php echo e($exam->start_date); ?>" | <?php echo e(getLanguage('class')); ?> <?php echo e($grade->title); ?>  <?php echo e($exam->title); ?></h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
            <form class="" action="<?php echo e(route('admin.exam.result.update')); ?>" method="post" enctype="multipart/form-data">

                <?php echo e(csrf_field()); ?>

                <input type="hidden" name="exam_id" value="<?php echo e($exam->id); ?>" />
                <input type="hidden" name="grade_id" value="<?php echo e($grade->id); ?>" />
                <div class="form-group">
                    <label><?php echo e(getLanguage('file')); ?></label>
                    <input type="file" name="file" value="" class="form-control" placeholder="File"/>
                    <?php if(isset($result->file)): ?>
                        <a target="_blank" href="<?php echo e(asset($result->file)); ?>">View File</a>
                        <?php endif; ?>
                </div>



                <div class="form-group">
                    <label><?php echo e(getLanguage('remarks')); ?></label>
                    <textarea class="form-control" name="remarks"><?php if(isset($result->remarks)): ?><?php echo e($result->remarks); ?> <?php endif; ?></textarea>
                </div>
                <button type="submit" class="btn btn-success waves-effect waves-light float-right">Update</button>
            </form>
        </div>
    </div><!-- /.modal-content -->
</div><!-- /.modal-dialog -->
