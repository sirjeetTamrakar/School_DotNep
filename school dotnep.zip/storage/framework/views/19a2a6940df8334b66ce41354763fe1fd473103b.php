
<?php if(\Illuminate\Support\Facades\Session::has('success')): ?>

    <br>
    <div class="alert alert-success container text-center text-uppercase" style="font-weight: bold">
        <?php echo session('success'); ?>

    </div>

<?php endif; ?>