<div class="modal fade" id="edit_content<?php echo e($content->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <form method="post" action="<?php echo e(route('admin.grade.edit',$content->id)); ?>">
        <?php echo csrf_field(); ?>
        <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel"><?php echo e(getLanguage('grade').' '.getLanguage('edit')); ?></h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
            <div class="form-group">
                <label for="title">Full Grade<?php echo e(getLanguage('title')); ?></label>
                <input type="text" name="title" value="<?php echo e($content->title); ?>" id="title" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="title">Short Grade Title</label>
                <input type="text" name="subtitle" value="<?php echo e($content->subtitle); ?>" id="subtitle" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="remarks"><?php echo e(getLanguage('remarks')); ?>:</label>
                <textarea  name="remarks" id="remarks" class="form-control"><?php echo e($content->remarks); ?></textarea>
            </div>
            <div class="form-group">
                <label for="title"><?php echo e(getLanguage('student').' '.getLanguage('information-1')); ?></label>
                <table class="table table-bordered">
                    <tr>
                        <th><?php echo e(getLanguage('ethnicity')); ?></th>
                        <th><?php echo e(getLanguage('male').' '.getLanguage('total')); ?></th>
                        <th><?php echo e(getLanguage('female').' '.getLanguage('total')); ?></th>
                    </tr>
                    <?php if($ethnicities->isNotEmpty()): ?>
                        <?php $__currentLoopData = $ethnicities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ethnicity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($ethnicity->title); ?></td>
                                <td><input type="number" name="ethnicity[male][<?php echo e($ethnicity->id); ?>]"
                                           value="<?php echo e(\App\model\StudentDetail::where('grade_id',$content->id)->where('ethnicity_id',$ethnicity->id)->get()->count() > 0
                                           ? \App\model\StudentDetail::where('grade_id',$content->id)->where('ethnicity_id',$ethnicity->id)->first()->male : ''); ?>"
                                            class="form-control">
                                </td>
                                <td><input type="number" name="ethnicity[female][<?php echo e($ethnicity->id); ?>]"
                                           value="<?php echo e(\App\model\StudentDetail::where('grade_id',$content->id)->where('ethnicity_id',$ethnicity->id)->get()->count() > 0
                                           ? \App\model\StudentDetail::where('grade_id',$content->id)->where('ethnicity_id',$ethnicity->id)->first()->female : ''); ?>"
                                           class="form-control">
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <tr>
                            <td><?php echo e(getLanguage('class-warning')); ?></td>
                            <td><a target="_blank" href="<?php echo e(route('admin.ethnicitys')); ?>"><?php echo e(getLanguage('add-new')." ".getLanguage('ethnicity')); ?>?</a></td>
                        </tr>
                    <?php endif; ?>
                </table>
            </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Save changes</button>
        </div>
        </div>
    </form>
  </div>
</div>
