

<?php $__env->startPush('style'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

    <div class="sub-banner">
        <div class="img-container">
            <img src="<?php echo e(asset(isset($settings['bannerImage']) ? $settings['bannerImage']: "")); ?>" alt="" />
            <div class="overlay">
                <div class="title">
                    <?php echo e(getFrontLanguage('download')."  ".getFrontLanguage('section')); ?>

                </div>
            </div>
        </div>
    </div>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('front.home')); ?>"><i class="fa fa-home"> </i><?php echo e(getFrontLanguage('home')); ?></a>
            </li>
            <li class="breadcrumb-item active" aria-current="page">
                <?php echo e(getFrontLanguage('download')); ?>

            </li>
        </ol>
    </nav>
    <div class="news-notice-section">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <div class="content-section">
                        <?php if($context->downloads->isNotEmpty()): ?>
                            <div class="notice-section">
                                <?php $__currentLoopData = $context->downloads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $download): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="notice-wrapper">
                                        <div class="title">
                                            <?php echo e($download->title); ?>

                                        </div>
                                        
                                        
                                        
                                        <div class="date">
                                            Publish Date: <?php echo e(getNepaliDate($download->created_at)); ?>

                                        </div>
                                        <div class="button-container">
                                            <a href="<?php echo e(route('front.singleDownload',[$download->id, getNepaliDate($download->created_at)])); ?>"><?php echo e(getFrontLanguage('view-detail')); ?></a>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php else: ?>
                            <div class="notice-section">
                                <div class="notice-wrapper">
                                    <div class="title">
                                        Empty
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="sidebar-section">
                        <div class="sidebar-title"><?php echo e(getFrontLanguage('recent')); ?> <?php echo e(getFrontLanguage('news-1')); ?></div>
                        <?php if($context->recent_news->isNotEmpty()): ?>
                            <ul>
                                <?php $__currentLoopData = $context->recent_news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <a href="<?php echo e(route('front.singleNews',[$news->id,getNepaliDate($news->created_at)])); ?>"><?php echo e($news->title); ?></a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php else: ?>
                            <span>No recent news to show.</span>
                        <?php endif; ?>
                    </div>
                    <hr />
                    <div class="sidebar-section">
                        <div class="sidebar-title"><?php echo e(getFrontLanguage('recent')); ?> <?php echo e(getFrontLanguage('event')); ?></div>
                        <?php if($context->recent_events->isNotEmpty()): ?>
                            <ul>
                                <?php $__currentLoopData = $context->recent_events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <a href="<?php echo e(route('front.singleEvent',[$event->id,getNepaliDate($event->created_at)])); ?>"><?php echo e($event->title); ?></a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php else: ?>
                            <span>No recent events to show.</span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('front.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>