
<div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title mt-0">Log Details</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
            <h3><?php echo e(class_basename($log->subject)); ?>&nbsp;<?php echo e($log->description); ?></h3>
            <?php if(isset($log->changes['attributes']) && isset($log->changes['old'])): ?>
                <h4>New Data</h4>
                <table class="table table-bordered">
                    <thead>
                    <tr>
                        <td>Key</td>
                        <td>Value</td>
                    </tr>
                    </thead>

                    <tbody>
                    <?php $__currentLoopData = $log->changes['attributes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keys=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($keys); ?></td>
                            <td><?php echo e($value); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>

                </table>
                <br>
                <h4>Old Data</h4>
                <table class="table table-bordered">

                    <thead>
                    <tr>
                        <td>Key</td>
                        <td>Value</td>
                    </tr>
                    </thead>

                    <tbody>
                    <?php $__currentLoopData = $log->changes['old']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keys=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($keys); ?></td>
                            <td><?php echo e($value); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>

                </table>
            <?php elseif(isset($log->changes['attributes']) && !isset($log->changes['old'])): ?>
                <h4>Value</h4>
                <table class="table table-bordered">

                    <thead>
                    <tr>
                        <td>Key</td>
                        <td>Value</td>
                    </tr>
                    </thead>

                    <tbody>
                    <?php $__currentLoopData = $log->changes['attributes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keys=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($keys); ?></td>
                            <td><?php echo e($value); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>

                </table>
            <?php else: ?>
                <span>No Additional Details.</span>
            <?php endif; ?>
        </div>
    </div><!-- /.modal-content -->
</div><!-- /.modal-dialog -->
