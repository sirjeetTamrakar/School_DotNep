

<?php $__env->startPush('style'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

    <div style="background-color: #E9ECEF;">
        <ol
                class="breadcrumb breadcrumb-fill0 container"
                style="background-color: #E9ECEF;"
        >
            <li>
                <a href="<?php echo e(route('front.home')); ?>" style="color: #2a98ef;"
                ><i class="fa fa-home"></i> Home &nbsp >> &nbsp</a
                >
            </li>
            <li>
                <a href="<?php echo e(route('front.staffs',$staffType->slug)); ?>" style="color: #2a98ef;"
                >Teachers &nbsp >> &nbsp</a
                >
            </li>
            <li class="active" style="color: #000;">Staff Details</li>
        </ol>
    </div>
    <section class="main-inner-section">
        <div class="container">
            <h1 class="inner-section-title"><?php echo e($staff->name); ?></h1>
            
            <div class="row">
                <div class="col-lg-5 col-md-12">
                    <div class="single-teacher-img">
                        <img
                                src="<?php echo e(asset($staff->image)); ?>"
                                alt="<?php echo e($staff->name); ?>"
                                class="profile"
                        />
                        
                            
                                    
                            
                                
                                    
                                        
                                            
                                                    
                                                    
                                                    
                                            
                                            
                                        
                                    
                                
                                
                                    
                                        
                                            
                                                    
                                                    
                                                    
                                            
                                            
                                        
                                    
                                
                                
                                    
                                        
                                            
                                                    
                                                    
                                                    
                                            
                                            
                                        
                                    
                                
                                
                                    
                                        
                                            
                                                    
                                                    
                                                    
                                            
                                            
                                        
                                    
                                
                            
                        
                    </div>
                </div>
                <div class="col-lg-7 col-md-12">
                    <div class="single-bio-details">
                        <ul>
                            <li><strong><?php echo e(getFrontLanguage('full-name-1')); ?>: </strong> <?php echo e($staff->name); ?></li>
                            
                                
                                
                            
                            <li><strong><?php echo e(getFrontLanguage('position')); ?>: </strong> <?php echo e($staff->job_title); ?></li>
                            <li><strong><?php echo e(getFrontLanguage('email-1')); ?>: </strong> <?php echo e($staff->email); ?></li>
                            <li><strong><?php echo e(getFrontLanguage('phone-1')); ?>: </strong> <?php echo e($staff->phone); ?></li>
                            <li><strong><?php echo e(getFrontLanguage('date-joined')); ?>: </strong><?php echo e($staff->join_date); ?></li>
                        </ul>
                        <?php if($staff->description): ?>
                            <div class="single-short-bio">
                                <h2><?php echo e(getFrontLanguage('a-short-bio')); ?></h2>
                                <p>
                                    <?php echo $staff->description; ?>

                                </p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('front.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>