

<?php $__env->startPush('style'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

    <div class="sub-banner">
        <div class="img-container">
            <img src="<?php echo e(asset(isset($settings['bannerImage'])?$settings['bannerImage']:'')); ?>" alt="" />
            <div class="overlay">
                <div class="title">
                    Tender
                </div>
            </div>
        </div>
    </div>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('front.home')); ?>"><i class="fa fa-home"> </i> Home</a></li>

            <li class="breadcrumb-item active" aria-current="page">
                Tender Notice
            </li>
        </ol>
    </nav>
    <div class="news-notice-section">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <div class="content-section">
                        <div class="notice-section">
                            <div class="notice-detail-wrapper">
                                <div class="main-title">
                                    <?php echo e($tender->title); ?>

                                </div>
                                <div class="long-description">
                                    <p><?php echo $tender->content; ?></p>

                                </div>
                                <div class="download-title">
                                    File Attachment
                                </div>
                                <ul>
                                    <?php if(isset($tender->file)): ?>
                                    <li>
                                        <div class="document-name">
                                            This is the document that can be download.
                                        </div>
                                        <div class="download-icon">
                                            <a href="<?php echo e(asset($tender->file)); ?>" target="_blank"> <i class="fa fa-download"></i></a>
                                        </div>
                                    </li>
                                    <?php else: ?>
                                        <li>
                                            <div class="document-name">
                                                No Attachments Available.
                                            </div>
                                        </li>
                                    <?php endif; ?>
                                </ul>
                                <div class="date">
                                    Publish Date: <?php echo e(getNepaliDate($tender->created_at)); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="sidebar-section">
                        <div class="sidebar-title">Other Tenders</div>
                        <?php if($context->recent_tenders->isNotEmpty()): ?>
                            <ul>
                                <?php $__currentLoopData = $context->recent_tenders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tend): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <a href="<?php echo e(route('front.singleTender',[$tend->id,getNepaliDate($tend->created_at)])); ?>"><?php echo e($tend->title); ?></a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php else: ?>
                            <span>No recent tenders to show.</span>
                        <?php endif; ?>

                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('front.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>