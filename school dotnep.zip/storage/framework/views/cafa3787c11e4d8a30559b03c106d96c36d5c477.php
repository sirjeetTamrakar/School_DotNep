

<?php $__env->startPush('style'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

    <div style="background-color: #E9ECEF;">
        <ol
                class="breadcrumb breadcrumb-fill0 container"
                style="background-color: #E9ECEF;"
        >
            <li>
                <a href="javascript:void(0);" style="color: #2a98ef;"
                ><i class="fa fa-home"></i> Home &nbsp >> &nbsp</a
                >
            </li>
            <li class="active" style="color: black;">Teachers</li>
        </ol>
    </div>

    <section class="main-inner-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-md-6">
                    <div class="inner-container">
                        <h1 class="inner-page-tite">Teachers</h1>
                        <p>
                            A teacher is a person who helps people to learn. A teacher often
                            works in a classroom. There are many different kinds of
                            teachers. Some teachers teach young children in kindergarten or
                            primary schools.
                        </p>
                        <div class="inner--container">
                            <div class="row">
                                <?php if($context->staffs->isNotEmpty()): ?>
                                    <?php $__currentLoopData = $context->staffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-md-6">
                                            <div class="single-item">
                                                <div
                                                        class="single-item-img"
                                                        style="background-image: url(<?php echo e(asset($staff->image)); ?>);"
                                                ></div>
                                                <div class="single-item-content">
                                                        <span class="content-title-text"
                                                        >Name: <?php echo e($staff->name); ?></span
                                                        >
                                                    <span class="content-nom-text"
                                                    >Address: <?php echo e($staff->address); ?></span
                                                    >
                                                    <span class="content-nom-text"
                                                    >Phone: <?php echo e($staff->phone); ?></span
                                                    >
                                                    <div class="morebtn text-right">
                                                        <a href="<?php echo e(route('front.teacherDetail',$staff->id)); ?>">
                                                            View Details <i class="fa fa-arrow-right"></i>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                            
                                
                                    
                                
                                
                                
                                
                                
                                    
                                
                            
                        
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="eventTemplate">
                        <div class="main-title">
                            Notice
                        </div>

                        <div class="tab-pane container active">
                            <div class="tab-detail">
                            <?php if($context->recent_notices->isNotEMpty()): ?>
                                <?php $__currentLoopData = $context->recent_notices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="tab-item">
                                        <div class="title">
                                            <a href="">
                                                <?php echo e($notice->title); ?>

                                            </a>
                                        </div>
                                        <div class="info">
                                            <div class="date"><?php echo e($notice->created_at->format('Y-m-d')); ?></div>
                                            <div class="morebtn">
                                                <a href="<?php echo e(route('front.singleNotice',$notice->id)); ?>"> View <i class="fa fa-arrow-right"></i> </a>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div class="morebtn">
                                    <a href="<?php echo e(route('front.notice')); ?>">
                                        View More <i class="fa fa-arrow-right"></i>
                                    </a>
                                </div>
                            <?php else: ?>
                                <div class="tab-item">
                                    <div class="title">
                                        <a href="">
                                            No Recent Notice Present.
                                        </a>
                                    </div>
                                </div>
                            <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('front.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>