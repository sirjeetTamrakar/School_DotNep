

<?php $__env->startPush('styles'); ?>

    

<?php $__env->stopPush(); ?>

<?php $__env->startSection('headers'); ?>

    
    <div class="row">
        <div class="col-sm-12">
            <div class="float-right page-breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Admin</a></li>
                    <li class="breadcrumb-item active"><a href="<?php echo e(route('admin.tender.all')); ?>">Tender</a></li>
                </ol>
            </div>
            <h5 class="page-title">Tender</h5>
            
        </div>
    </div>
    <!-- end row -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>

    
    <div class="row">
        <div class="col-12">
            <div class="card m-b-30">
                <div class="card-body">

                    <h4 class="mt-0 header-title text-center">All School Tender</h4>
                    <div>
                        <a href="<?php echo e(route('admin.tender.add')); ?>" class="pull-right btn btn-primary">
                            ADD NEW</a>
                    </div>
                    <table id="datatable" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                        <thead>
                        <tr>
                            <th>S.No</th>
                            <th>Name</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                        </thead>


                        <tbody>
                            <?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($content->id); ?></td>
                                <td><?php echo e($content->title); ?></td>
                                <td>
                                    <a href="<?php echo e(route('admin.tender.changestatus',$content->id)); ?>">
                                    <?php if($content->status == "Active"): ?>
                                        <button data-id="<?php echo e($content->id); ?>" class="btn-chnage-status btn btn-sm btn-default text-primary btn-success" title="Active"><i class="ion-toggle-filled"></i> </button>
                                    <?php else: ?>
                                        <button data-id="<?php echo e($content->id); ?>" class="btn-chnage-status btn btn-sm btn-default text-primary btn-danger" title="Inactive"><i class="ion-toggle"></i></button>
                                    <?php endif; ?>
                                    </a>
                                </td>
                                <td>
                                    <button class="btn btn-primary btn-icon-text mr-2 p-1" title="View Details" data-toggle="modal" data-target="#view_content<?php echo e($content->id); ?>">
                                        <i class="fa fa-eye"></i>
                                    </button>
                                    <?php echo $__env->make('admin.tender.details', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                                    <a href="<?php echo e(route('admin.tender.edit',$content->slug)); ?>" class="btn btn-success btn-icon-text mr-2 p-1" title="Edit">
                                        <i class="fa fa-edit"></i>
                                    </a>

                                    <button class="btn btn-danger btn-icon-text mr-2 p-1"
                                            data-toggle="modal" data-target="#delete_content<?php echo e($content->id); ?>" title="Delete">
                                        <i class="fa fa-trash"></i>
                                    </button>
                                    <?php echo $__env->make('admin.tender.delete', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    


<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

    
    <!-- Required datatable js -->
    <script src="<?php echo e(asset('admin/assets/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/plugins/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

    <!-- Datatable init js -->
    <script src="<?php echo e(asset('admin/assets/pages/datatables.init.js')); ?>"></script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>