

<?php $__env->startPush('style'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

    <div style="background-color: #E9ECEF;">
        <ol
                class="breadcrumb breadcrumb-fill0 container"
                style="background-color: #E9ECEF;"
        >
            <li>
                <a href="<?php echo e(route('front.home')); ?>" style="color: #2a98ef;"
                ><i class="fa fa-home"></i> Home &nbsp >> &nbsp</a
                >
            </li>
            <li class="active" style="color: black;">Staffs</li>
        </ol>
    </div>

    <section class="main-inner-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-md-6">
                    <div class="inner-container">
                        <h1 class="inner-page-tite"><?php echo e($context->staffType->title); ?></h1>
                        <p>
                            <?php echo e($context->staffType->remarks); ?>

                        </p>
                        <div class="inner--container">
                            <div class="row">
                                <?php if($context->staffs->isNotEmpty()): ?>
                                    <?php $__currentLoopData = $context->staffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <div class="col-md-4 col-6">
                                        <div class="single-item">

                                            <div
                                                    class="single-item-img"
                                                    style="
                                                        background-image: url('<?php echo e(asset('thumbnail/'.$staff->image)); ?>');
                                                    "
                                            ></div>
                                            <div class="content-title">
                                                <?php echo e($staff->name); ?>

                                            </div>
                                            <div class="morebtn">
                                                <a href="<?php echo e(route('front.staffDetail',[$staff->id,$context->staffType->slug])); ?>">
                                                    View More
                                                </a>
                                            </div>

                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                        </div>

                        
                            
                                
                                    
                                
                                
                                
                                
                                
                                    
                                
                            
                        
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="eventTemplate">
                        <div class="main-title">
                            Notice
                        </div>

                        <div class="tab-pane container active">
                            <div class="tab-detail">
                            <?php if($context->recent_notices->isNotEMpty()): ?>
                                <?php $__currentLoopData = $context->recent_notices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="tab-item">
                                        <div class="title">
                                            <a href="">
                                                <?php echo e($notice->title); ?>

                                            </a>
                                        </div>
                                        <div class="info">
                                            <div class="date"><?php echo e($notice->created_at->format('Y-m-d')); ?></div>
                                            <div class="morebtn">
                                                <a href="<?php echo e(route('front.singleNotice',[$notice->id,getNepaliDate($notice->created_at)])); ?>"> View <i class="fa fa-arrow-right"></i> </a>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div class="morebtn">
                                    <a href="<?php echo e(route('front.notice')); ?>">
                                        View More <i class="fa fa-arrow-right"></i>
                                    </a>
                                </div>
                            <?php else: ?>
                                <div class="tab-item">
                                    <div class="title">
                                        <a href="">
                                            No Recent Notice Present.
                                        </a>
                                    </div>
                                </div>
                            <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('front.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>