<div id="navbar">
    <div class="container d-flex justify-content-between">
        <div class="right-container">
            <div class="logo">
                <img
                        src="<?php echo e(isset($settings['logo']) ? $settings['logo'] : "front/assets/images/logo.png"); ?>"
                        alt="" class="img-fluid" />
            </div>
            <div class="center-container">
                <div class="company_name"><?php echo e(isset($settings['name']) ? $settings['name'] : "High School"); ?></div>
                <div class="company_address">
                    <?php echo e(isset($settings['address']) ? $settings['address'] : ""); ?>

                </div>
            </div>
        </div>

        <div class="right-container d-none d-md-flex">
            <div class="ministry">
                <div class="company_province">Province No. 5</div>
                <div class="company_ministry">
                    Ministry of Education <br />
                    Science And Technology
                </div>
            </div>
            <div class="logo">
                <img
                        src="<?php echo e(isset($settings['vdc_logo']) ? $settings['vdc_logo'] : "front/assets/images/logo.png"); ?>"
                        alt="" class="img-fluid" />
            </div>
        </div>
    </div>
</div>

<div id="myNav" class="overlay">
    <a class="closebtn" onclick="closeNav()">
        &times;
    </a>

    <div class="overlay-content">
        <a href="<?php echo e(route('front.home')); ?>">Home</a>

        <div class="dropdown">
            <button class="dropbtn">
                School Overview <i class="fa fa-caret-down"></i>
            </button>
            <div class="dropdown-content">
                <a href="<?php echo e(route('front.about')); ?>">About Us</a>
                <a href="<?php echo e(route('front.mission-vision')); ?>">Vision & Mission</a>
                <a href="<?php echo e(route('front.principal-note')); ?>">Principal Note</a>
                <a href="<?php echo e(route('front.gallery')); ?>">Gallery</a>
            </div>
        </div>

        <div class="dropdown">
            <button class="dropbtn">
                Facilities <i class="fa fa-caret-down"></i>
            </button>
            <div class="dropdown-content">
                <?php if(isset($asset_categories)): ?>
                    <?php $__currentLoopData = $asset_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('front.asset_category', $category->id)); ?>"><?php echo e($category->title); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>
        <div class="dropdown">
            <button class="dropbtn">
                Members Enrolled <i class="fa fa-caret-down"></i>
            </button>
            <div class="dropdown-content">
                <a href="<?php echo e(route('front.teachers')); ?>">Teachers</a>
                <a href="<?php echo e(route('front.administration')); ?>">Administration</a>
            </div>
        </div>

        <div class="dropdown">
            <button class="dropbtn">
                News & Notice <i class="fa fa-caret-down"></i>
            </button>
            <div class="dropdown-content">
                <a href="<?php echo e(route('front.notice')); ?>">Notice</a>
                <a href="<?php echo e(route('front.news')); ?>">News</a>
                <a href="<?php echo e(route('front.events')); ?>">Events</a>
                <a href="<?php echo e(route('front.tender')); ?>">Tender</a>
            </div>
        </div>
        <a href="calender.html">Calender</a>
        <a href="<?php echo e(route('front.contact')); ?>">Contact Us</a>
    </div>
</div>
<div id="secondNavbar" class="d-none  d-lg-block">
    <div class="container ">
        <div class="nav  d-flex justify-content-around">
            <a href="<?php echo e(route('front.home')); ?>">Home</a>

            <div class="dropdown">
                <button class="dropbtn">
                    School Overview <i class="fa fa-caret-down"></i>
                </button>
                <div class="dropdown-content">
                    <a href="<?php echo e(route('front.about')); ?>">About Us</a>
                    <a href="<?php echo e(route('front.mission-vision')); ?>">Vision & Mission</a>
                    <a href="<?php echo e(route('front.principal-note')); ?>">Principal Note</a>
                    <a href="<?php echo e(route('front.gallery')); ?>">Gallery</a>
                </div>
            </div>

            <div class="dropdown">
                <button class="dropbtn">
                    Facilities <i class="fa fa-caret-down"></i>
                </button>
                <div class="dropdown-content">
                    <?php if(isset($asset_categories)): ?>
                        <?php $__currentLoopData = $asset_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route('front.asset_category', $category->id)); ?>"><?php echo e($category->title); ?></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>
            <div class="dropdown">
                <button class="dropbtn">
                    Members Enrolled <i class="fa fa-caret-down"></i>
                </button>
                <div class="dropdown-content">
                    <a href="<?php echo e(route('front.teachers')); ?>">Teachers</a>
                    <a href="<?php echo e(route('front.administration')); ?>">Administration</a>
                </div>
            </div>

            <div class="dropdown">
                <button class="dropbtn">
                    News & Notice <i class="fa fa-caret-down"></i>
                </button>
                <div class="dropdown-content">
                    <a href="<?php echo e(route('front.notice')); ?>">Notice</a>
                    <a href="<?php echo e(route('front.news')); ?>">News</a>
                    <a href="<?php echo e(route('front.events')); ?>">Events</a>
                    <a href="<?php echo e(route('front.tender')); ?>">Tender</a>
                </div>
            </div>
            <a href="calender.html">Calender</a>
            <a href="<?php echo e(route('front.contact')); ?>">Contact Us</a>
            <form action="">
                <div class="form-group">
                    <select name="" id="">
                        <option value="">Nep</option>
                        <option value="">Eng</option>
                    </select>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="top-navbar">
    <div class="container d-flex justify-content-between">
				<span onclick="openNav()" class="d-block d-lg-none">
					<i class="fa fa-bars"></i>
				</span>

        <form action="" class="d-block d-lg-none">
            <div class="form-group">
                <select name="" id="">
                    <option value="">Nep</option>
                    <option value="">Eng</option>
                </select>
            </div>
        </form>
    </div>
</div>