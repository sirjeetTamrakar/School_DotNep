<?php $__env->startPush('styles'); ?>


    <!-- Dropzone css -->

    <style>
        .image_preview{
            width: 100%;
            min-height: 100px;
            margin-top: 15px;

            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            color: #cccccc;

        }

        .image_preview img{
            width: 150px;
            height: auto;
        }
    </style>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('headers'); ?>

    
    <div class="row">
        <div class="col-sm-12">
            <div class="float-right page-breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#">Admin</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Admin</a></li>
                    <li class="breadcrumb-item active"><a href="<?php echo e(route('admin.staff.all')); ?>">Staffs</a></li>
                    <li class="breadcrumb-item active"><a href="<?php echo e(route('admin.staff.add')); ?>">Add</a></li>
                </ol>
            </div>
            <h5 class="page-title"> Add New Staff Member</h5>
        </div>
    </div>
    <!-- end row -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>

    
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="modal-title text-center" id="exampleModalLabel">Basic Information </h4>

                    <form method="post" action="<?php echo e(route('admin.staff.store')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <div class="row">
                            <div class="col-md-8">
                                <div class="form-group">
                                    <label for="name">Name</label>
                                    <input type="text" name="name" id="name" class="form-control" required>
                                </div>
                                <div class="form-group">
                                    <label for="title">Job Title:</label>
                                    <textarea  name="job_title" id="title" class="form-control" required></textarea>
                                </div>

                                <div class="form-group">
                                    <label for="staff_type">Staff Type:</label>
                                    <select name="staff_type_id" id="staff_type" class="form-control">
                                        <option value="" selected disabled="disabled">Select a staff type</option>
                                        <?php $__currentLoopData = $staff_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($staff_type->id); ?>"><?php echo e($staff_type->title); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="phone">Phone:</label>
                                    <input type="text" name="phone" id="phone" class="form-control" required>
                                </div>
                                <div class="form-group">
                                    <label for="email">Email:</label>
                                    <input type="text" name="email" id="email" class="form-control" required>
                                </div>

                                <div class="form-group">
                                    <label for="ethnicity">Address:</label>
                                    <textarea name="address" id="address" class="form-control"></textarea>
                                </div>

                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="gender">Gender:</label>
                                    <select name="gender" id="gender" class="form-control" required>
                                        <option value="Male">Male</option>
                                        <option value="Female">Female</option>
                                        <option value="Other">Other</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="DOB">DOB:</label>
                                    <input type="date" name="DOB" id="DOB" class="form-control" required>
                                </div>
                                <div class="form-group">
                                    <label for="DOB">Join Date:</label>
                                    <input type="date" name="join_date" id="DOB" class="form-control" required>
                                </div>
                                <div class="form-group">
                                    <label for="photo">Profile Image</label>
                                    <input type="file" name="image" id="photo" class="form-control">
                                </div>
                                <div class="image_preview">
                                    <img src="<?php echo e(asset('admin/img/profile_icon.png')); ?>" alt="" id="preview_image" name style="height: 100px; width: auto">
                                </div>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-success pull-right">Save changes</button>
                    </form>
                </div>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>


<!-- Dropzone js -->


<script>
    $('input[type=file]').on('change', function(e){
        uploadimages(e)
    });

    function uploadimages(e){
        const file = e.target.files[0];
        if(file){
            const reader = new FileReader();
            reader.addEventListener('load',function(){
                const previewImage = document.querySelector('#preview_image')
                console.log(previewImage)
                previewImage.setAttribute("src",reader.result)
            });
            reader.readAsDataURL(file);
        }
    }
</script>


<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>