

<?php $__env->startPush('styles'); ?>

    

<?php $__env->stopPush(); ?>

<?php $__env->startSection('headers'); ?>

    
    <div class="row">
        <div class="col-sm-12">
            <div class="float-right page-breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Admin</a></li>
                    <li class="breadcrumb-item active"><a href="<?php echo e(route('admin.subject.all')); ?>">Subjects</a></li>
                </ol>
            </div>
            <h5 class="page-title">Subjects</h5>
            
        </div>
    </div>
    <!-- end row -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>

    
    <div class="row">
        <div class="col-12">
            <div class="card m-b-30">
                <div class="card-body">

                    <h4 class="mt-0 header-title">All Subjects</h4>
                    <div>
                        <button class="pull-right btn btn-primary"
                            data-toggle="modal" data-target="#add_content">
                            ADD NEW</button>
                    </div>
                    <?php echo $__env->make('admin.subject.add', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <table id="datatable" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                        <thead>
                        <tr>
                            <th>S.No</th>
                            <th>Title</th>
                            <th>Grade</th>
                            <th>Remarks</th>
                            <th>Action</th>
                        </tr>
                        </thead>


                        <tbody>
                            <?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($content->id); ?></td>
                                <td><?php echo e($content->title); ?></td>
                                <td><?php echo e($content->grade->title); ?></td>
                                <td><?php echo e($content->remarks); ?></td>
                                <td>
                                    <button class="btn btn-primary btn-icon-text mr-2 p-1"
                                        data-toggle="modal" data-target="#edit_content<?php echo e($content->id); ?>">
                                        <i class="fa fa-edit"></i>
                                    </button>
                                    <?php echo $__env->make('admin.subject.edit', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                    <button class="btn btn-danger btn-icon-text mr-2 p-1"
                                        data-toggle="modal" data-target="#delete_content<?php echo e($content->id); ?>">
                                        <i class="fa fa-trash"></i>
                                    </button>
                                    <?php echo $__env->make('admin.subject.delete', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    


<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

    
    <script src="<?php echo e(asset('admin/assets/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/plugins/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

    <!-- Datatable init js -->
    <script src="<?php echo e(asset('admin/assets/pages/datatables.init.js')); ?>"></script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>