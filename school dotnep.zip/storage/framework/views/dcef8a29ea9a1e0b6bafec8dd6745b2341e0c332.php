<?php $__env->startPush('style'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>


    <div class="student-section">
        <div class="container">
            <div class="student-title">
                <?php echo e(getFrontLanguage('student-detail')); ?>

            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover">
                            <thead>
                            <tr>
                                <th><?php echo e(getFrontLanguage('serial')); ?></th>
                                <th><?php echo e(getFrontLanguage('class-1')); ?></th>
                                <?php $__currentLoopData = $ethnicities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ethnicity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <th><?php echo e($ethnicity->title); ?></th>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <th><?php echo e(getFrontLanguage('total-students')); ?></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e(getFrontLanguage('class-1')); ?> <?php echo e($content->title); ?></td>
                                    <?php $__currentLoopData = $ethnicities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ethnicity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <td>
                                            <?php echo e(getFrontLanguage('male-1')); ?>: <?php echo e(isset($content->male[$ethnicity->id])? $content->male[$ethnicity->id]:0); ?>

                                            <br><?php echo e(getFrontLanguage('female-1')); ?>: <?php echo e(isset($content->female[$ethnicity->id])? $content->female[$ethnicity->id]:0); ?>

                                        </td>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <td> <?php echo e($content->total_students); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="student-section">
        <div class="container">
            <div class="student-title">
                <?php echo e(getFrontLanguage('total-ethnicity-wise-details')); ?>

            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover">
                            <thead>
                            <tr>
                                <th><?php echo e(getFrontLanguage('serial')); ?></th>
                                <th><?php echo e(getFrontLanguage('ethnicity-1')); ?></th>
                                <th><?php echo e(getFrontLanguage('male-1')); ?></th>
                                <th><?php echo e(getFrontLanguage('female-1')); ?></th>
                                <th><?php echo e(getFrontLanguage('total-students')); ?></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $ethnicities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ethnicity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($ethnicity->title); ?></td>
                                    <td><?php echo e($ethnicity->male); ?></td>
                                    <td><?php echo e($ethnicity->female); ?></td>
                                    <td> <?php echo e($ethnicity->total); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td></td>
                                    <td><strong><?php echo e(getFrontLanguage('total-1')); ?></strong></td>
                                    <td><strong><?php echo e($ethnicity_total_male); ?></strong></td>
                                    <td><strong><?php echo e($ethnicity_total_female); ?></strong></td>
                                    <td><strong><?php echo e($ethnicity_total_students); ?></strong></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="student-section">
        <div class="container">
            <div class="student-title">
                <?php echo e(getFrontLanguage('student-list')); ?>

            </div>
            <div class="row">
                <div class="col-md-3">
                    <div class="sidebar">
                        <div class="sidebar-title">
                            <?php echo e(getFrontLanguage('class-1')); ?>

                        </div>
                        <ul class="nav nav-tabs">
                            <?php $count =1; ?>
                            <?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($content->students->count() > 0): ?>
                                    <li class="nav-item">
                                        <a class="nav-link <?php if($count == 1): ?> active  <?php endif; ?> "
                                           data-toggle="tab" href="#class<?php echo e($content->id); ?>"> <?php echo e(getFrontLanguage('class-1')); ?> <?php echo e($content->title); ?></a>
                                    </li>
                                     <?php $count++; ?>
                                <?php endif; ?>
                               
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
                <div class="col-md-9">
                    <div class="tab-content">
                        <?php $count =1; ?>
                        <?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($content->students->count() > 0): ?>
                                <div class="tab-pane container <?php if($count == 1): ?> active  <?php endif; ?> " id="class<?php echo e($content->id); ?>">
                                    <div class="table-responsive">
                                        <table class="table table-striped table-bordered table-hover">
                                            <thead>
                                            <tr>
                                                <th><?php echo e(getFrontLanguage('serial')); ?></th>
                                                <th><?php echo e(getFrontLanguage('name-1')); ?></th>
                                                <th><?php echo e(getFrontLanguage('father-s').' '.getFrontLanguage('name-1')); ?></th>
                                                <th><?php echo e(getFrontLanguage('mother-s').' '.getFrontLanguage('name-1')); ?></th>
                                                <th><?php echo e(getFrontLanguage('birth-date-1')); ?></th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php $__currentLoopData = $content->students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($loop->iteration); ?></td>
                                                    <td><?php echo e($student->name); ?></td>
                                                    <td><?php echo e($student->father_name); ?></td>
                                                    <td><?php echo e($student->mother_name); ?></td>
                                                    <td><?php echo e($student->dob); ?></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <?php $count++; ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('front.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>