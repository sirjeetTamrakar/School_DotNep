<?php if(isset($popup)): ?>
<div class="row">
    <div class="col-md-6">
        <div class="form-group">
            <label for="">Pop-up Title</label>
            <input type="text" name="title" value="<?php echo e($popup->title); ?>" class="form-control" placeholder="Pop-up Title....">
        </div>
        <div class="form-group">
            <label for="">Pop-up Images</label><br>
            <img src="<?php echo e(asset($popup->image)); ?>" height="100px" width="100px" alt=""><br><br>
            <input type="file" name="image" class="form-control">
        </div>
        <div class="form-group">
            <label for="">Pop-up status</label>
            <select name="status" id="" class="form-control">
                <option> Select one</option>

                <option value="active" <?php if($popup->status == "active"): ?>
                    selected
                <?php endif; ?>> Active</option>
                <option value="inactive" <?php if($popup->status == "inactive"): ?>
                    selected
                <?php endif; ?>>InActive</option>
            </select>
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group">
            <label for="">Pop-up Link</label>
            <input type="text" name="link" class="form-control" value="<?php echo e($popup->link); ?>" placeholder="Pop-up Link....">
        </div>
        <div class="form-group">
            <label for="">Pop-up position</label>
            <input type="number" name="position" class="form-control" value="<?php echo e($popup->position); ?>" placeholder="Pop-up Postion....">
        </div>
    </div>

</div>
<?php else: ?>
<div class="row">
    <div class="col-md-6">
        <div class="form-group">
            <label for="">Pop-up Title</label>
            <input type="text" name="title" class="form-control" placeholder="Pop-up Title....">
        </div>
        <div class="form-group">
            <label for="">Pop-up Images</label>
            <input type="file" name="image" class="form-control">
        </div>
        <div class="form-group">
            <label for="">Pop-up status</label>
            <select name="status" id="" class="form-control">
                <option> Select one</option>
                <option value="active"> Active</option>
                <option value="inactive">InActive</option>
            </select>
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group">
            <label for="">Pop-up Link</label>
            <input type="text" name="link" class="form-control" placeholder="Pop-up Link....">
        </div>
        <div class="form-group">
            <label for="">Pop-up position</label>
            <input type="number" name="position" class="form-control" placeholder="Pop-up Postion....">
        </div>
    </div>

</div>
<?php endif; ?>
