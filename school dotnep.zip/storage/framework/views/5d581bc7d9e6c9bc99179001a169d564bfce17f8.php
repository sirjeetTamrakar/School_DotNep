<?php $__env->startPush('style'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

    <div class="sub-banner">
        <div class="img-container">
            <img src="assets/images/banner1.jpg" alt="" />
            <div class="overlay">
                <div class="title">
                    Tender Notice
                </div>
            </div>
        </div>
    </div>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('front.home')); ?>"><i class="fa fa-home"> </i> Home</a>
            </li>
            <li class="breadcrumb-item active" aria-current="page">
                Tender
            </li>
        </ol>
    </nav>
    <div class="news-notice-section">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <div class="content-section">
                        <div class="notice-section">
                            <?php if($context->tenders->isNotEmpty()): ?>
                                <?php $__currentLoopData = $context->tenders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tender): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="notice-wrapper">
                                        <div class="title">
                                            <?php echo e($tender->title); ?>

                                        </div>
                                        <div class="short-description">
                                            <?php echo substr($tender->content,0,300); ?>

                                        </div>
                                        <div class="date">
                                            Publish Date: <?php echo e($tender->created_at->format('Y-m-d')); ?>

                                        </div>
                                        <div class="button-container">
                                            <a href="<?php echo e(route('front.singleTender',$tender->id)); ?>">View Detail</a>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <span>No tenders available currently.</span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="sidebar-section">
                        <div class="sidebar-title">Recent News</div>
                            <?php if($context->recent_news->isNotEmpty()): ?>
                                <ul>
                                    <?php $__currentLoopData = $context->recent_news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <a href="<?php echo e(route('front.singleNews',$news->id)); ?>"><?php echo e($news->title); ?></a>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <?php else: ?>
                                <span>No recent news to show.</span>
                            <?php endif; ?>

                            <hr />

                            <div class="sidebar-title">Recent Events</div>
                            <?php if($context->recent_events->isNotEmpty()): ?>
                                <ul>
                                    <?php $__currentLoopData = $context->recent_events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <a href="<?php echo e(route('front.singleEvent',$event->id)); ?>"><?php echo e($event->title); ?></a>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <?php else: ?>
                                <span>No recent events to show.</span>
                            <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('front.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>