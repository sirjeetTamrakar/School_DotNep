
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title mt-0"><?php echo e(getLanguage('exam').' '.getLanguage('edit')); ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form class="" action="<?php echo e(route('admin.exam.update')); ?>" method="post" enctype="multipart/form-data">

                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="exam_id" value="<?php echo e($exam->id); ?>" />
                    <div class="form-group">
                        <label><?php echo e(getLanguage('title')); ?></label>
                        <input type="text" name="title" value="<?php echo e($exam->title); ?>" class="form-control" required placeholder="Title"/>
                    </div>
                    <div class="form-group">
                        <label><?php echo e(getLanguage('exam-start-date')); ?></label>
                        <input type="text" name="start_date" value="<?php echo e($exam->start_date); ?>" class="form-control nepali-calendar" id="edit_date<?php echo e($exam->id); ?>" required />
                    </div>

                    <div class="form-group">
                        <label><?php echo e(getLanguage('grade').' '.getLanguage('select')); ?></label>
                        <select class="form-control js-example-basic-multiple" name="grade_id[]" multiple="multiple">
                            <option value="" disabled><?php echo e(getLanguage('grade').' '.getLanguage('select')); ?></option>
                            <?php $__currentLoopData = $grades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($grade->id); ?>"
                                <?php $__currentLoopData = $exam->grades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gradeItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($gradeItem->id == $grade->id): ?> selected <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                ><?php echo e($grade->subtitle); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>


                    <div class="form-group">
                        <label><?php echo e(getLanguage('remarks')); ?></label>
                        <textarea class="form-control" name="remarks"><?php echo e($exam->remarks); ?> </textarea>
                    </div>
                    <button type="submit" data-id="<?php echo e($exam->id); ?>" class="btn btn-success waves-effect waves-light float-right res_update">Update</button>
                </form>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
    <script>
        $(document).ready(function() {
            $('.js-example-basic-multiple').select2();
        });
    </script>
