<?php $__env->startPush('style'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>


    <div class="sub-banner">
        <div class="img-container">
            <img src="assets/images/banner1.jpg" alt="" />
            <div class="overlay">
                <div class="title">
                    News
                </div>
            </div>
        </div>
    </div>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('front.home')); ?>">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">
                News
            </li>
        </ol>
    </nav>
    <div class="news-notice-section">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <div class="content-section">
                        <div class="news-section">
                            <div class="row">
                                <?php if($context->news->isNotEmpty()): ?>
                                    <?php $__currentLoopData = $context->news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-md-6">
                                            <a href="<?php echo e(route('singleNews',$news->id)); ?>">
                                                <div class="img-container">
                                                    <img
                                                            src="<?php echo e(asset(isset($news->image)?$news->image:"front/assets/images/banner1.jpg")); ?>"
                                                            alt=""
                                                            class="img-fluid"
                                                    />
                                                    <div class="overlay">
                                                        <div class="title">
                                                            <?php echo e($news->title); ?>

                                                        </div>
                                                        <div class="date">March 03, 2020</div>
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <div>
                                        No News To Display !!
                                    </div>
                                <?php endif; ?>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="sidebar-section">
                        <div class="sidebar-title">Recent Notices</div>
                        <?php if($context->recent_notices->isNotEmpty()): ?>
                            <ul>
                                <?php $__currentLoopData = $context->recent_notices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <a href="<?php echo e(route('front.singleNews',$notice->id)); ?>"><?php echo e($notice->title); ?></a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php else: ?>
                            <span>No recent notices to show.</span>
                        <?php endif; ?>

                        <hr />

                        <div class="sidebar-title">Recent Events</div>
                        <?php if($context->recent_events->isNotEmpty()): ?>
                            <ul>
                                <?php $__currentLoopData = $context->recent_events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <a href="<?php echo e(route('front.singleEvent',$event->id)); ?>"><?php echo e($event->title); ?></a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php else: ?>
                            <span>No recent events to show.</span>
                        <?php endif; ?>

                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('front.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>