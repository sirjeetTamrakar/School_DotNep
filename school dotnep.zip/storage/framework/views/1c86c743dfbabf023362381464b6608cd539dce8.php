<div class="footer ">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-6">
                <div class="img-logo-container ">
                    <img
                            src="<?php echo e(asset(isset($settings['logo']) ? $settings['logo'] : 'front/assets/images/school-logo.png')); ?>"
                            class="img-fluid"
                            alt=""
                    />
                </div>
                <div class="company_name text-center"><?php echo e(isset($settings['name']) ? $settings['name'] : "High School"); ?> </div>
                <div class="company_address"><?php echo e(isset($settings['address']) ? $settings['address'] : "Jamal, Kathmandu"); ?></div>
            </div>

            <div class="col-lg-3 col-md-6 ">
                <div class="link-container">
                    <div class="link-title"><?php echo e(getFrontLanguage('important-links')); ?></div>
                    <ul>
                        <li>
                            <a href="<?php echo e(route('front.home')); ?>"><?php echo e(getFrontLanguage('home')); ?></a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('front.about')); ?>"><?php echo e(getFrontLanguage('about-us')); ?></a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('front.contact')); ?>"><?php echo e(getFrontLanguage('contact-us')); ?></a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('front.gallery')); ?>"><?php echo e(getFrontLanguage('gallery')); ?></a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 ">
                <div class="link-container">
                    <div class="link-title"><?php echo e(getFrontLanguage('similar-websites')); ?></div>
                    <ul>
                        <li>
                            <a href=""
                            >Similar sites like Durbar High School will be here</a
                            >
                        </li>
                        <li>
                            <a href=""
                            >Similar sites like Durbar High School will be here</a
                            >
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 ">
                <div class="link-container">
                    <div class="link-title"><?php echo e(getFrontLanguage('information')); ?></div>
                    <ul>
                        <li>
                            <a href="<?php echo e(route('front.download')); ?>"><?php echo e(getFrontLanguage('download')); ?></a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('front.news')); ?>"><?php echo e(getFrontLanguage('news-1')); ?></a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('front.notice')); ?>"><?php echo e(getFrontLanguage('notice-1')); ?></a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('front.events')); ?>"><?php echo e(getFrontLanguage('event')); ?></a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="top-footer">
            
                
                        
                        
                        
                
                
                        
                        
                        
                
            
            <div class="social-icon">
                <ul>
                    <li>
                        <a href="" style=" background: #3b5a9b">
                            <i class="fab fa-facebook"></i>
                        </a>
                    </li>
                    <li>
                        <a href="" style="background: #2a98ef">
                            <i class="fab fa-twitter"></i>
                        </a>
                    </li>
                    <li>
                        <a href="" style="background: #db2814">
                            <i class="fab fa-google-plus"></i>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        <hr style="background: #dbdbdb" />
        <div class="bottom-footer d-flex justify-content-between">
            <div class="copywrite">
                Copyright &copy; 2020 <?php echo e(isset($settings['name']) ? $settings['name'] : "High School"); ?>. All Rights Reserved.
            </div>
            <ul class="privacy-link d-flex justify-content-between">
                <li>
                    <a href=""> Privacy |</a>
                </li>
                <li>
                    <a href=""> Disclaimer |</a>
                </li>
                <li>
                    <a href=""> Copyright </a>
                </li>
            </ul>
        </div>
    </div>
</div>
