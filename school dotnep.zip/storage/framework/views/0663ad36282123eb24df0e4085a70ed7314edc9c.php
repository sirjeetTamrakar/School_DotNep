
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title mt-0">Edit Testimonial</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form class="" action="<?php echo e(route('admin.testimonial.update')); ?>" method="post" enctype="multipart/form-data">

                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="testimonial_id" value="<?php echo e($testimonial->id); ?>" />
                    <div class="form-group">
                        <label>Name</label>
                        <input type="text" name="name" value="<?php echo e($testimonial->name); ?>" class="form-control" required placeholder="Full Name" />
                    </div>

                    <div class="form-group">
                        <label>Designation</label>
                        <input type="text" value="<?php echo e($testimonial->designation); ?>" name="designation" required class="form-control" placeholder="Link"/>
                    </div>

                    <div class="form-group">
                        <label>Image</label>
                        <input type="file" name="image" class="form-control" placeholder="Image"/>
                        <?php if($testimonial->image): ?>
                            <img src="<?php echo e(asset('thumbnail/'.$testimonial->image)); ?>" style="width: 100px;">
                            <?php endif; ?>
                    </div>

                    <div class="form-group">
                        <label>Comment</label>
                        <textarea name="comment" class="form-control" required placeholder="Comment"><?php echo e($testimonial->comment); ?></textarea>
                    </div>

                    <div class="form-group">
                        <label>Status</label>
                        <select class="form-control" name="status">
                            <option value="">Select Status</option>
                            <option value="Active" <?php if($testimonial->status == "Active"): ?> selected <?php endif; ?> >Active</option>
                            <option value="Inactive" <?php if($testimonial->status == "Inactive"): ?> selected <?php endif; ?> >Inactive</option>
                        </select>
                    </div>

                    <button type="submit" class="btn btn-success waves-effect waves-light float-right">Update</button>
                </form>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
