<!-- ========== Left Sidebar Start ========== -->
<div class="left side-menu">
    <button type="button" class="button-menu-mobile button-menu-mobile-topbar open-left waves-effect">
        <i class="ion-close"></i>
    </button>

    <div class="left-side-logo d-block d-lg-none">
        <div class="text-center">
            <a href="<?php echo e(url('admins/dashboard')); ?>" class="logo">
                <?php if(getAbout('logo')): ?>
                    <img src="<?php echo e(asset('thumbnail/'.getAbout('logo'))); ?>" style="width: 70px;" alt="logo">
                <?php endif; ?>
            </a>
        </div>
    </div>

    <div class="sidebar-inner slimscrollleft">

        <div id="sidebar-menu">
            <ul>

                <li>
                    <a href="<?php echo e(url('admins/dashboard')); ?>" class="waves-effect">
                        <i class="dripicons-meter"></i>
                        <span> <?php echo e(getLanguage('dashboard')); ?> </span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo e(route('admin.grade.students')); ?>" class="waves-effect">
                        <i class="dripicons-user-group"></i>
                        <span> <?php echo e(getLanguage('students')); ?> </span>
                    </a>
                </li>



                <li>
                    <a href="<?php echo e(route('admin.sliders')); ?>" class="waves-effect">
                        <i class="dripicons-store"></i>
                        <span> <?php echo e(getLanguage('slider')); ?> </span>
                    </a>
                </li>


                <?php if(Auth::user()->role_id == 1): ?>
                <li>
                    <a href="<?php echo e(route('admin.occupations')); ?>" class="waves-effect">
                        <i class="dripicons-briefcase"></i>
                        <span> <?php echo e(getLanguage('occupation')); ?> </span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('admin.ethnicitys')); ?>" class="waves-effect">
                        <i class="dripicons-home"></i>
                        <span> <?php echo e(getLanguage('ethnicity')); ?> </span>
                    </a>
                </li>
                <?php endif; ?>

                
                    
                        
                        
                    
                


                <li>
                    <a href="<?php echo e(route('admin.album.all')); ?>" class="waves-effect">
                        <i class="dripicons-photo-group"></i>
                        <span> <?php echo e(getLanguage('album')); ?> </span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo e(route('admin.grade.all')); ?>" class="waves-effect">
                        <i class="dripicons-graduation"></i>
                        <span> <?php echo e(getLanguage('grade')); ?> </span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo e(route('admin.exams')); ?>" class="waves-effect">
                        <i class="dripicons-pencil"></i>
                        <span> <?php echo e(getLanguage('exam')); ?> </span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo e(route('admin.subject.all')); ?>" class="waves-effect">
                        <i class="dripicons-folder-open"></i>
                        <span> <?php echo e(getLanguage('subject')); ?> </span>
                    </a>
                </li>

                <li class="has_sub">
                    <a href="javascript:void(0);" class="waves-effect"><i class="dripicons-user-id"></i> <span> <?php echo e(getLanguage('staff-setup')); ?> </span> <span class="menu-arrow float-right"><i class="mdi mdi-chevron-right"></i></span></a>
                    <ul class="list-unstyled">
                        <?php if(Auth::user()->role_id == 1): ?>
                            <li><a href="<?php echo e(route('admin.staff_type.all')); ?>"><?php echo e(getLanguage('stafftype')); ?></a></li>
                        <?php endif; ?>
                        <li><a href="<?php echo e(route('admin.staff.all')); ?>"><?php echo e(getLanguage('staff')); ?></a></li>
                        <li><a href="<?php echo e(route('admin.staffbygrade.all')); ?>"><?php echo e(getLanguage('staffclasssubject')); ?></a></li>
                    </ul>
                </li>
                <li>
                    <a href="<?php echo e(route('admin.committees')); ?>" class="waves-effect">
                        <i class="dripicons-pin"></i>
                        <span> <?php echo e(getLanguage('committee')); ?> </span>
                    </a>
                </li>

                <li class="has_sub">
                    <a href="javascript:void(0);" class="waves-effect"><i class="dripicons-device-desktop"></i> <span><?php echo e(getLanguage('cms')); ?></span> <span class="menu-arrow float-right"><i class="mdi mdi-chevron-right"></i></span></a>
                    <ul class="list-unstyled">
                        <li><a href="<?php echo e(route('admin.event.all')); ?>"><?php echo e(getLanguage('events')); ?></a></li>
                        <li><a href="<?php echo e(route('admin.news.all')); ?>"><?php echo e(getLanguage('news')); ?></a></li>
                        <li><a href="<?php echo e(route('admin.notice.all')); ?>"><?php echo e(getLanguage('notice')); ?></a></li>
                        <li><a href="<?php echo e(route('admin.tender.all')); ?>"><?php echo e(getLanguage('tender')); ?></a></li>
                        <li><a href="<?php echo e(route('admin.scholarship.all')); ?>"><?php echo e(getLanguage('scholarship')); ?></a></li>
                    </ul>
                </li>

                <li>
                    <a href="<?php echo e(route('admin.download.all')); ?>" class="waves-effect">
                        <i class="dripicons-cloud-download"></i>
                        <span> Download </span>
                    </a>
                </li>

                <li class="has_sub">
                    <a href="javascript:void(0);" class="waves-effect"><i class="dripicons-article"></i> <span><?php echo e(getLanguage('about')); ?></span> <span class="menu-arrow float-right"><i class="mdi mdi-chevron-right"></i></span></a>
                    <ul class="list-unstyled">
                        <li><a href="<?php echo e(route('admin.basic.info')); ?>"><?php echo e(getLanguage('basic-info')); ?></a></li>
                        <li><a href="<?php echo e(route('admin.about')); ?>"><?php echo e(getLanguage('about')); ?></a></li>
                        
                        <li><a href="<?php echo e(route('admin.welcome.message')); ?>"><?php echo e(getLanguage('message')); ?></a></li>
                        <li><a href="<?php echo e(route('admin.testimonials')); ?>"><?php echo e(getLanguage('testimonial')); ?></a></li>
                        <li><a href="<?php echo e(route('admin.about.student')); ?>"><?php echo e(getLanguage('student')); ?></a></li>
                    </ul>
                </li>


                <?php if(Auth::user()->role_id == 1): ?>
                    <li>
                        <a href="<?php echo e(route('admin.users')); ?>" class="waves-effect">
                            <i class="dripicons-user"></i>
                            <span> <?php echo e(getLanguage('user')); ?> </span>
                        </a>
                    </li>
                <?php endif; ?>

                <li class="has_sub">
                    <a href="javascript:void(0);" class="waves-effect"><i class="dripicons-archive"></i> <span><?php echo e(getLanguage('language')); ?></span> <span class="menu-arrow float-right"><i class="mdi mdi-chevron-right"></i></span></a>
                    <ul class="list-unstyled">
                        <li><a href="<?php echo e(route('admin.languages')); ?>"><?php echo e(getLanguage('dashboardLanguage')); ?></a></li>
                        <li><a href="<?php echo e(route('admin.languagesFrontend')); ?>"><?php echo e(getLanguage('homepageLanguage')); ?></a></li>
                    </ul>
                </li>

            </ul>
        </div>
        <div class="clearfix"></div>
    </div> <!-- end sidebarinner -->
</div>
<!-- Left Sidebar End -->
