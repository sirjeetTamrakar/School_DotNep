

<?php $__env->startPush('style'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

    <div class="sub-banner">
        <div class="img-container">
            <img src="<?php echo e(asset(isset($settings['bannerImage'])?$settings['bannerImage']:'')); ?>" alt="" />
            <div class="overlay">
                <div class="title">
                    <?php echo e(getFrontLanguage('scholarship-1')); ?>

                </div>
            </div>
        </div>
    </div>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('front.home')); ?>"><i class="fa fa-home"> </i> Home</a></li>

            <li class="breadcrumb-item active" aria-current="page">
                <?php echo e(getFrontLanguage('scholarship-1')); ?>

            </li>
        </ol>
    </nav>
    <div class="news-notice-section">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <div class="content-section">
                        <div class="notice-section">
                            <div class="notice-detail-wrapper">
                                <div class="main-title">
                                    <?php echo e($scholarship->title); ?>

                                </div>
                                <div class="long-description">
                                    <p><?php echo $scholarship->content; ?></p>

                                </div>
                                <div class="download-title">
                                    File Attachment
                                </div>
                                <ul>
                                    <?php if(isset($scholarship->file)): ?>
                                        <li>
                                            <div class="document-name">
                                                This is the document that can be download.
                                            </div>
                                            <div class="download-icon">
                                                <a href="<?php echo e(asset($scholarship->file)); ?>" target="_blank"> <i class="fa fa-download"></i></a>
                                            </div>
                                        </li>
                                    <?php else: ?>
                                        <li>
                                            <div class="document-name">
                                                No Attachments Available.
                                            </div>
                                        </li>
                                    <?php endif; ?>
                                </ul>
                                <div class="date">
                                    Publish Date: <?php echo e(getNepaliDate($scholarship->created_at)); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="sidebar-section">
                        <div class="sidebar-title">Other Scholarships</div>
                        <?php if($context->recent_scholarships->isNotEmpty()): ?>
                            <ul>
                                <?php $__currentLoopData = $context->recent_scholarships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $scholar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <a href="<?php echo e(route('front.singleScholarship',[$scholar->id,getNepaliDate($scholar->created_at)])); ?>"><?php echo e($scholar->title); ?></a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php else: ?>
                            <span>No recent scholarship to show.</span>
                        <?php endif; ?>

                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('front.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>